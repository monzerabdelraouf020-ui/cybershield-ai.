"""
CyberShield AI - Seed & Benchmark Dataset Generator
Includes realistic, diverse phishing and legitimate messages in:
- Egyptian Arabic (Colloquial / Dialectal)
- Modern Standard Arabic (MSA)
- English
Plus balanced benign & phishing URL datasets for academic reproducibility.
"""

from typing import List, Dict, Any

# 1. Multilingual Text Dataset (1 = Phishing, 0 = Legitimate)
TEXT_SAMPLES: List[Dict[str, Any]] = [
    # --- EGYPTIAN ARABIC PHISHING (Label: 1) ---
    {
        "text": "مبروك كسبت 50000 جنيه من فودافون كاش! دوس ع اللينك واستلم فلوسك فورا قبل ما العرض ينتهي: http://voda-cash-win.xyz/claim",
        "label": 1,
        "language": "arz",
        "category": "lottery_scam"
    },
    {
        "text": "عميلنا العزيز، تم ايقاف محفظتك الذكية في انستاباي بسبب عدم تحديث البيانات. لتجنب الحظر النهائي ادخل هنا وحدث بياناتك: http://instapay-security-portal.top/login",
        "label": 1,
        "language": "arz",
        "category": "wallet_phishing"
    },
    {
        "text": "تنبيه هام من البنك الاهلي: حسابك البنكي معلق حاليا. يرجى الضغط عالرابط وإدخال كود التحقق والفيزا لفك الحظر: http://192.168.1.45/nbe-unlock",
        "label": 1,
        "language": "arz",
        "category": "bank_impersonation"
    },
    {
        "text": "الحق عرض كارفور مصر بمناسبة العيد! قسيمة شراء مجانية بقيمة 3000 جنيه لأول 100 واحد يسجلوا بياناتهم هنا: http://carrefour-voucher-free.buzz",
        "label": 1,
        "language": "arz",
        "category": "fake_voucher"
    },
    {
        "text": "شحنتك من نون معلقة في مكتب التوزيع بسبب رسوم شحن 25 جنيه لم تسدد. ادفع الرسوم دلوقتي من الرابط عشان متترجعش: http://noon-delivery-track.click/pay",
        "label": 1,
        "language": "arz",
        "category": "delivery_scam"
    },
    {
        "text": "خدمه عملاء بنك مصر: مطلوب فورا تحديث بطاقتك الائتمانية قبل الساعه 6 مساء عشان حسابك هيقف نهائيا. ادخل اللينك: http://banquemisr-online.xyz/update",
        "label": 1,
        "language": "arz",
        "category": "bank_impersonation"
    },
    {
        "text": "فرصة عمل من البيت براتب يصل لـ 1500 جنيه يوميا بدون خبرة! ابعت رقم كاش بتاعك وسجل في المنصة حالا: http://easy-money-eg.top",
        "label": 1,
        "language": "arz",
        "category": "job_scam"
    },
    {
        "text": "اورنج بتقدملك 100 جيجا مجانية لكل عملائها! اشترك قبل انتهاء الوقت وسجل برقم تليفونك والرمز اللي هيوصلك: http://orange-free-internet.monster/promo",
        "label": 1,
        "language": "arz",
        "category": "telecom_scam"
    },
    {
        "text": "مبروك يا فندم رقمك تم اختياره في سحب عشوائي لكارت مشتريات من بي تك. اكد هويتك واستلم الكارت: http://btech-giftcard-claims.xyz",
        "label": 1,
        "language": "arz",
        "category": "lottery_scam"
    },
    {
        "text": "تم محاولة خصم 4200 جنيه من بطاقتك في مشتريات اونلاين. لو دي مش عمليتك دوس هنا فورا لوقف العملية واسترداد فلوسك: http://security-cib-verify.rest/fraud",
        "label": 1,
        "language": "arz",
        "category": "panic_alert"
    },
    {
        "text": "مبروك فزت معنا بجائزة كبرى سيارة هيونداي من مسابقة الحلم! ادخل رقم بطاقتك وكود التأكيد للاستلام: http://mbc-dream-claim.buzz",
        "label": 1,
        "language": "arz",
        "category": "lottery_scam"
    },
    {
        "text": "إشعار حظر مؤقت: محفظتك في فوري تم تجميدها بسبب نشاط غير اعتيادي. لتنشيط المحفظة ورفع التجميد اضغط هنا: http://fawry-active-portal.top",
        "label": 1,
        "language": "arz",
        "category": "wallet_phishing"
    },
    {
        "text": "ابعت كود الـ OTP اللي هيجيلك فورا لمندوب خدمة العملاء عشان نفك حظر الفيزا بتاعتك ومنسحبش الرصيد.",
        "label": 1,
        "language": "arz",
        "category": "otp_theft"
    },
    {
        "text": "منحة العمالة غير المنتظمة: وزارة القوى العاملة قررت صرف 1000 جنيه لكل مواطن. سجل بياناتك ورقم بطاقتك القومي فورا: http://manpower-grant-eg.click",
        "label": 1,
        "language": "arz",
        "category": "government_lure"
    },

    # --- MSA ARABIC PHISHING (Label: 1) ---
    {
        "text": "تنبيه أمني عاجل: لقد تم تسجيل دخول غير مصرح به إلى حسابك المصرفي من جهاز مجهول. يرجى تأكيد ملكيتك للحساب فوراً عبر الرابط التالي: https://secure-bank-login-portal.top/auth",
        "label": 1,
        "language": "ar",
        "category": "bank_impersonation"
    },
    {
        "text": "إدارة البريد الإلكتروني: صندوق بريدك ممتلئ بنسبة 98% وسيتم حذف الرسائل الواردة خلال 24 ساعة. لتفادي الإغلاق قم بترقية السعة مجاناً: http://webmail-quota-upgrade.xyz/login",
        "label": 1,
        "language": "ar",
        "category": "credential_harvesting"
    },
    {
        "text": "البريد السريع: تعذر تسليم طردك الدولي بسبب نقص في تفاصيل العنوان ورسوم جمركية غير مدفوعة (12 دولار). يرجى السداد لتحديد موعد التسليم: http://dhl-express-tracking.club/pay",
        "label": 1,
        "language": "ar",
        "category": "delivery_scam"
    },
    {
        "text": "إشعار من منصة التداول: تم تجميد محفظتك الرقمية بسبب لوائح مكافحة غسيل الأموال. يرجى إيداع مبلغ الضمان وإدخال الكلمات المفتاحية لفك الحظر: http://binance-safety-verify.top",
        "label": 1,
        "language": "ar",
        "category": "crypto_scam"
    },
    {
        "text": "عزيزي العميل، تم تعليق حساب باي بال الخاص بك بسبب أنشطة مشبوهة. يرجى التحقق من هويتك لتجنب الإغلاق الدائم للحساب: http://paypal-resolution-center.xyz",
        "label": 1,
        "language": "ar",
        "category": "brand_impersonation"
    },
    {
        "text": "لقد تلقيت تحويلاً مالياً معلقاً بقيمة $3,450 دولار أمريكي. اضغط على الرابط وقم بتسجيل الدخول إلى محفظتك لاستلام المبلغ فورا: http://wire-transfer-gateway.click",
        "label": 1,
        "language": "ar",
        "category": "financial_lure"
    },

    # --- ENGLISH PHISHING (Label: 1) ---
    {
        "text": "URGENT: Your PayPal account has been temporarily restricted due to unauthorized login attempts. Verify your identity now to avoid permanent suspension: https://paypal-security-account.top/verify",
        "label": 1,
        "language": "en",
        "category": "brand_impersonation"
    },
    {
        "text": "Dear customer, your Netflix subscription payment failed. Your service will be cancelled within 12 hours. Update billing information here: http://netflix-billing-update.xyz/login",
        "label": 1,
        "language": "en",
        "category": "subscription_scam"
    },
    {
        "text": "Apple ID Alert: Your iCloud account has been locked for security reasons. Please visit our support verification center immediately: http://appleid-support-verify.click/auth",
        "label": 1,
        "language": "en",
        "category": "tech_support"
    },
    {
        "text": "DHL Express: Your shipment #84920492 could not be delivered due to an invalid shipping address. Update your address and pay 1.99 USD re-delivery fee: http://dhl-track-package.top/shipment",
        "label": 1,
        "language": "en",
        "category": "delivery_scam"
    },
    {
        "text": "Congratulations! You have been selected as the Amazon 1,000 USD Gift Card winner of the day. Claim your reward before midnight: http://amazon-gift-winner.buzz/claim",
        "label": 1,
        "language": "en",
        "category": "lottery_scam"
    },
    {
        "text": "Microsoft 365 Security Notice: Your password expires in 2 hours. Keep your current password and prevent email deletion by clicking: http://office365-pass-keep.icu/portal",
        "label": 1,
        "language": "en",
        "category": "credential_harvesting"
    },
    {
        "text": "Metamask Security Alert: Your wallet needs immediate KYC verification. Unverified wallets will be burned. Connect your seed phrase to proceed: http://metamask-security-sync.cfd",
        "label": 1,
        "language": "en",
        "category": "crypto_scam"
    },

    # --- EGYPTIAN ARABIC LEGITIMATE (Label: 0) ---
    {
        "text": "فودافون كاش: تم تحويل مبلغ 1500 جنيه إلى رقم 01012345678 بنجاح. مصاريف العملية 1 جنيه. رصيدك الحالي هو 3200 جنيه. للاستعلام اطلب *9#.",
        "label": 0,
        "language": "arz",
        "category": "telecom_receipt"
    },
    {
        "text": "انستاباي: رمز التأكيد السري الخاص بك لتسجيل الدخول هو 749281. تحذير: لا تشارك هذا الرمز مع أي شخص حتى موظفي البنك.",
        "label": 0,
        "language": "arz",
        "category": "legit_otp"
    },
    {
        "text": "البنك الأهلي المصري: تم سحب مبلغ 500 جنيه من ماكينة صراف آلي برقم بطاقة تنتهي بـ 4920. الرصيد المتاح 18,400 جنيه.",
        "label": 0,
        "language": "arz",
        "category": "bank_notification"
    },
    {
        "text": "أهلاً بك في تطبيق طلبات. طلبك رقم #4829 في الطريق إليك مع الكابتن أحمد. لتتبع الطلب افتح التطبيق مباشرة.",
        "label": 0,
        "language": "arz",
        "category": "ecommerce_delivery"
    },
    {
        "text": "كود تفعيل حسابك في تطبيق أنا فودافون هو: 5821. هذا الرمز صالح لمدة 5 دقائق فقط.",
        "label": 0,
        "language": "arz",
        "category": "legit_otp"
    },
    {
        "text": "تم تجديد باقة الإنترنت المنزلي بنجاح. استمتع بـ 200 جيجابايت صالحة حتى نهاية الشهر. لمعرفة استهلاكك زور موقعنا الرسمي we.com.eg.",
        "label": 0,
        "language": "arz",
        "category": "telecom_notification"
    },
    {
        "text": "مساء الخير يا فندم، بنأكد على ميعاد حجز سيادتك في عيادة الأسنان غداً الساعة 5 مساء في فرع المعادي. للاعتذار يرجى الرد على الرسالة.",
        "label": 0,
        "language": "arz",
        "category": "appointment"
    },
    {
        "text": "أمازون مصر: تم شحن طلبك #402-91823. يمكنك متابعة حالة الشحنة من قسم طلباتي داخل تطبيق أمازون.",
        "label": 0,
        "language": "arz",
        "category": "ecommerce_delivery"
    },
    {
        "text": "إيزي كاش: تم إيداع راتبك الشهري بقيمة 8500 جنيه. شكراً لاستخدامك خدماتنا المصرفية.",
        "label": 0,
        "language": "arz",
        "category": "bank_notification"
    },
    {
        "text": "فوري: تم دفع فاتورة الكهرباء بنجاح بمبلغ 340 جنيه. رقم العملية المرجعي هو 8920194829.",
        "label": 0,
        "language": "arz",
        "category": "bill_payment"
    },

    # --- MSA ARABIC LEGITIMATE (Label: 0) ---
    {
        "text": "جامعة القاهرة: نود إعلامكم ببدء تسجيل المقررات الدراسية للفصل الثاني عبر البوابة الإلكترونية الرسمية للجامعة ابتداء من الأحد القادم.",
        "label": 0,
        "language": "ar",
        "category": "education"
    },
    {
        "text": "الخطوط الجوية: تم تأكيد حجز تذكرتك رقم ET-84920 إلى دبي. يرجى التواجد في المطار قبل موعد الرحلة بثلاث ساعات.",
        "label": 0,
        "language": "ar",
        "category": "travel"
    },
    {
        "text": "مرحباً بك في منصة أبشر. رمز التحقق لمرة واحدة لدخول حسابك هو: 409182. تنبيه: لا تفصح عن هذا الرمز لأي جهة.",
        "label": 0,
        "language": "ar",
        "category": "legit_otp"
    },
    {
        "text": "شكراً لاشتراكك في النشرة البريدية التقنية. يمكنك إدارة تفضيلات اشتراكك أو إلغائه في أي وقت من إعدادات حسابك.",
        "label": 0,
        "language": "ar",
        "category": "newsletter"
    },
    {
        "text": "تقرير الحالة الأسبوعي لمشروعك البرمجي: تم دمج 4 طلبات سحب وحل 12 مشكلة برمجية بنجاح دون أي أعطال.",
        "label": 0,
        "language": "ar",
        "category": "work_update"
    },

    # --- ENGLISH LEGITIMATE (Label: 0) ---
    {
        "text": "Your Google verification code is 849201. Don't share this code with anyone. Our employees will never ask for it.",
        "label": 0,
        "language": "en",
        "category": "legit_otp"
    },
    {
        "text": "Your Uber ride with Mohamed has arrived outside. Toyota Corolla, Plate number: ABC 1234. Please wear your seatbelt.",
        "label": 0,
        "language": "en",
        "category": "ride_receipt"
    },
    {
        "text": "GitHub: [Security alert] Dependencies updated in repository cybershield-ai. All 4 pull requests passed automatic CI tests.",
        "label": 0,
        "language": "en",
        "category": "developer_alert"
    },
    {
        "text": "Hi Alex, thanks for your purchase at Apple Store. Your digital invoice #INV-92810 is ready and can be accessed in your account.",
        "label": 0,
        "language": "en",
        "category": "receipt"
    },
    {
        "text": "Reminder: Team sprint retrospective is scheduled for tomorrow at 10:00 AM UTC via Google Meet. Agenda doc attached in calendar invite.",
        "label": 0,
        "language": "en",
        "category": "calendar_meeting"
    },
    {
        "text": "LinkedIn: 3 people viewed your profile this week. See who viewed your profile by visiting linkedin.com.",
        "label": 0,
        "language": "en",
        "category": "social_network"
    }
]

# 2. Benchmark URL Dataset (1 = Phishing, 0 = Legitimate)
URL_SAMPLES: List[Dict[str, Any]] = [
    # Phishing URLs
    {"url": "http://192.168.1.104/vodafone-cash/login.php", "label": 1, "category": "ip_host"},
    {"url": "http://instapay-security-portal.top/verification", "label": 1, "category": "suspicious_tld"},
    {"url": "http://nbe-online-banking.cib-portal.xyz/login", "label": 1, "category": "brand_and_tld"},
    {"url": "https://paypal.com.account-update-center.icu/webscr", "label": 1, "category": "subdomain_spoof"},
    {"url": "http://carrefour-gift-card-egypt.buzz/claim", "label": 1, "category": "voucher_scam"},
    {"url": "http://appleid.apple.com.verify-device-support.top", "label": 1, "category": "subdomain_spoof"},
    {"url": "http://banquemisr-portal-login.cfd/auth", "label": 1, "category": "bank_impersonation"},
    {"url": "https://bit.ly/3xFakeVodafonePromo", "label": 1, "category": "shortener_lure"},
    {"url": "http://dhl-express-package-redelivery.rest/pay", "label": 1, "category": "delivery_phish"},
    {"url": "http://office365-secure-login-microsoft.online/auth", "label": 1, "category": "brand_lure"},
    {"url": "http://fawry-wallet-active.xyz/account", "label": 1, "category": "wallet_scam"},
    {"url": "http://xn--pypal-4ve.com/signin", "label": 1, "category": "punycode_homograph"},
    {"url": "http://netflix-billing-resolve.surf/update", "label": 1, "category": "streaming_phish"},
    {"url": "http://binance-security-kyc.top/wallet", "label": 1, "category": "crypto_phish"},
    {"url": "http://amazon-prime-prize.click/winner", "label": 1, "category": "lottery_phish"},

    # Legitimate URLs
    {"url": "https://www.google.com", "label": 0, "category": "search_engine"},
    {"url": "https://www.nbe.com.eg", "label": 0, "category": "egyptian_bank"},
    {"url": "https://www.banquemisr.com", "label": 0, "category": "egyptian_bank"},
    {"url": "https://www.cibeg.com", "label": 0, "category": "egyptian_bank"},
    {"url": "https://web.vodafone.com.eg", "label": 0, "category": "telecom_portal"},
    {"url": "https://www.orange.eg", "label": 0, "category": "telecom_portal"},
    {"url": "https://www.instapay.eg", "label": 0, "category": "official_fintech"},
    {"url": "https://www.fawry.com", "label": 0, "category": "official_fintech"},
    {"url": "https://www.amazon.eg", "label": 0, "category": "ecommerce"},
    {"url": "https://github.com", "label": 0, "category": "developer_platform"},
    {"url": "https://en.wikipedia.org/wiki/Phishing", "label": 0, "category": "reference"},
    {"url": "https://www.microsoft.com/en-us", "label": 0, "category": "technology"},
    {"url": "https://www.paypal.com", "label": 0, "category": "fintech"},
    {"url": "https://www.apple.com", "label": 0, "category": "technology"},
    {"url": "https://stackoverflow.com/questions", "label": 0, "category": "developer_community"}
]

def get_text_dataset():
    return TEXT_SAMPLES

def get_url_dataset():
    return URL_SAMPLES
