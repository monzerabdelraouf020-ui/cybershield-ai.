from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from pathlib import Path

from app.config import STATIC_DIR
from app.database import (
    init_db,
    insert_analysis,
    get_recent_analyses,
    get_analysis_by_id,
    save_feedback,
    get_model_versions,
    get_datasets,
    get_dashboard_stats
)
from app.fusion.risk_fusion import risk_fusion
from app.nlp.text_classifier import text_classifier
from app.url.url_classifier import url_classifier
from app.data.train import run_training_pipeline

app = FastAPI(
    title="CyberShield AI API",
    description="Multilingual AI-Powered Phishing Detection & Explainability Engine (Arabic, Egyptian Dialect, English)",
    version="1.0.0"
)

# Enable CORS for cross-origin requests (e.g. mobile app, external clients)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Database on startup
@app.on_event("startup")
def startup_event():
    init_db()
    # Reload models into memory
    text_classifier.load()
    url_classifier.load()

# Request schemas
class AnalyzeRequest(BaseModel):
    text: str = Field(..., min_length=2, description="The message text, email content, or URL to inspect")

class FeedbackRequest(BaseModel):
    analysis_id: int
    actual_label: str = Field(..., pattern="^(phishing|legitimate)$")
    comments: Optional[str] = None

# API Routes
@app.post("/api/analyze")
async def analyze_message(req: AnalyzeRequest):
    if not req.text.strip():
        raise HTTPException(status_code=400, detail="Input text cannot be empty.")

    # Execute fusion analysis
    result = risk_fusion.evaluate(req.text)

    # Save to SQLite database
    db_record = {
        "input_type": result["input_type"],
        "raw_text": result["raw_text"],
        "extracted_urls": result["extracted_urls"],
        "detected_language": result["detected_language"],
        "text_risk_score": result["text_risk_score"],
        "url_risk_score": result["url_risk_score"],
        "final_risk_score": result["final_risk_score"],
        "risk_level": result["risk_level"],
        "verdict": result["verdict"],
        "confidence": result["confidence"],
        "explanation_factors": result["explanation_factors"],
        "processing_time_ms": result["processing_time_ms"],
        "user_feedback": None
    }
    analysis_id = insert_analysis(db_record)
    result["id"] = analysis_id

    return result

@app.get("/api/history")
async def get_history(limit: int = 50):
    return get_recent_analyses(limit)

@app.get("/api/analysis/{analysis_id}")
async def get_single_analysis(analysis_id: int):
    res = get_analysis_by_id(analysis_id)
    if not res:
        raise HTTPException(status_code=404, detail="Analysis record not found.")
    return res

@app.post("/api/feedback")
async def submit_feedback(req: FeedbackRequest):
    fb_id = save_feedback(req.analysis_id, req.actual_label, req.comments)
    return {"status": "success", "feedback_id": fb_id, "message": "Feedback recorded successfully"}

@app.get("/api/models")
async def list_models():
    return get_model_versions()

@app.get("/api/datasets")
async def list_datasets():
    return get_datasets()

@app.get("/api/stats")
async def get_stats():
    return get_dashboard_stats()

@app.post("/api/retrain")
async def retrain_models():
    results = run_training_pipeline()
    text_classifier.load()
    url_classifier.load()
    return {"status": "retrained", "results": results}

@app.get("/api/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "CyberShield AI",
        "text_model_loaded": text_classifier.model is not None,
        "url_model_loaded": url_classifier.model is not None
    }

# Mount static assets
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

@app.get("/")
async def serve_index():
    index_file = STATIC_DIR / "index.html"
    if index_file.exists():
        return FileResponse(index_file)
    return {"message": "CyberShield AI Backend Online. Static assets will be served here."}
