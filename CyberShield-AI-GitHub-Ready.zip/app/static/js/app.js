// CyberShield AI - Bilingual Application Engine

const I18N = {
    ar: {
        badge_research: "مشروع بحثي معتمد",
        brand_subtitle: "نظام ذكي متعدد اللغات لكشف التصيد الاحتيالي وتحليل الروابط",
        tab_scanner: "الفحص الفوري",
        tab_metrics: "أداء النماذج",
        tab_history: "سجل التحليلات",
        tab_architecture: "المعمارية التقنية",
        stat_total_scans: "إجمالي الفحوصات",
        stat_phishing_detected: "تهديدات تصيد تم كشفها",
        stat_suspicious: "رسائل مشبوهة",
        stat_safe_verified: "رسائل آمنة مؤكدة",
        stat_avg_latency: "متوسط زمن الاستجابة",
        scanner_header: "تحليل الرسائل والروابط متعددة اللغات",
        presets_title: "نماذج اختبار سريعة:",
        btn_clear: "مسح",
        btn_analyze: "بدء التحليل الشامل بالذكاء الاصطناعي",
        waiting_analysis_title: "في انتظار إدخال البيانات",
        waiting_analysis_desc: "أدخل نص رسالة أو رابط واضغط على \"بدء التحليل الشامل\" للحصول على تقرير المخاطر التفسيري.",
        risk_score: "درجة الخطر",
        confidence_label: "مستوى الثقة:",
        engine_text_title: "محرك تحليل النصوص (NLP)",
        engine_url_title: "محرك فحص الروابط (URL Engine)",
        meta_detected_lang: "اللغة واللهجة:",
        meta_ml_prob: "احتمالية نموذج TF-IDF:",
        meta_heuristics_score: "قواعد الإلحاح والاستدراج:",
        trigger_words_label: "الكلمات المفتاحية المؤثرة:",
        meta_urls_found: "عدد الروابط المستخرجة:",
        xai_title: "تفسير أسباب التحذير (Explainable AI Factors)",
        recommendations_title: "الإجراءات الأمنية الموصى بها",
        feedback_prompt: "هل كان هذا التحليل دقيقاً؟ ساعد في تحسين النموذج البحثي:",
        metrics_head: "تقييم النماذج البحثية (Academic Benchmarks)",
        metrics_sub: "قياسات دقيقة ومستقلة على مجموعات اختبار حقيقية للهجات العربية والإنجليزية والروابط",
        btn_retrain: "إعادة تدريب النماذج وتقييمها",
        datasets_title: "بيانات التدريب والتحقق (Corpus Datasets)",
        history_head: "سجل التحليلات وقاعدة البيانات (SQLite)",
        history_sub: "أرشيف لعمليات الكشف ونتائج دمج المخاطر لتدقيق الأمان",
        btn_refresh: "تحديث السجل",
        arch_head: "المعمارية التقنية والتكامل مع Android",
        arch_sub: "تصميم Modular متقدم يتيح التوسع ونقل قاعدة البيانات إلى PostgreSQL وتكامل تطبيقات الهاتف بسهولة",
        verdict_phishing: "رصد هجوم تصيد احتيالي",
        verdict_suspicious: "تحذير: رسالة أو رابط مشبوه",
        verdict_safe: "آمن: لم يتم رصد أي تهديد",
        lang_arz: "مصري عامي (Egyptian Dialect)",
        lang_ar: "عربية فصحى (Standard Arabic)",
        lang_en: "إنجليزية (English)",
        lang_mixed: "مختلط (Mixed)",
        lang_unknown: "غير محدد"
    },
    en: {
        badge_research: "Verified Research Project",
        brand_subtitle: "Multilingual AI-Powered Phishing & URL Threat Detection System",
        tab_scanner: "Live Scanner",
        tab_metrics: "Model Benchmarks",
        tab_history: "Analysis Logs",
        tab_architecture: "Architecture & API",
        stat_total_scans: "Total Scans",
        stat_phishing_detected: "Phishing Detected",
        stat_suspicious: "Suspicious Flagged",
        stat_safe_verified: "Safe Verified",
        stat_avg_latency: "Avg Latency",
        scanner_header: "Multilingual Text & URL Deep Threat Inspection",
        presets_title: "Quick Test Scenarios:",
        btn_clear: "Clear",
        btn_analyze: "Run Deep AI Threat Inspection",
        waiting_analysis_title: "Awaiting Input Data",
        waiting_analysis_desc: "Enter message text or a URL and click 'Run Deep AI Threat Inspection' for an explainable risk breakdown.",
        risk_score: "Risk Score",
        confidence_label: "Confidence:",
        engine_text_title: "Text Analysis Engine (NLP)",
        engine_url_title: "URL Analysis Engine",
        meta_detected_lang: "Detected Language/Dialect:",
        meta_ml_prob: "TF-IDF Model Prob:",
        meta_heuristics_score: "Urgency/Threat Heuristics:",
        trigger_words_label: "Influential Trigger Keywords:",
        meta_urls_found: "Extracted URLs Count:",
        xai_title: "Explainable Risk Factors (XAI)",
        recommendations_title: "Recommended Actionable Security Measures",
        feedback_prompt: "Was this analysis accurate? Help improve our research model:",
        metrics_head: "Academic Model Benchmarks & Metrics",
        metrics_sub: "Independent cross-validation on Egyptian dialect, MSA Arabic, English, and URL datasets",
        btn_retrain: "Retrain & Evaluate Models",
        datasets_title: "Training & Validation Datasets",
        history_head: "Analysis Audit Logs & Database (SQLite)",
        history_sub: "Persistent inspection records and fusion scoring for audit and compliance",
        btn_refresh: "Refresh History",
        arch_head: "Technical Architecture & Android Readiness",
        arch_sub: "Modular pipeline designed for PostgreSQL migration and native Android app integration",
        verdict_phishing: "Phishing Attack Detected",
        verdict_suspicious: "Warning: Suspicious Message or URL",
        verdict_safe: "Verified Safe: No Threats Detected",
        lang_arz: "Egyptian Colloquial Arabic",
        lang_ar: "Modern Standard Arabic (MSA)",
        lang_en: "English",
        lang_mixed: "Multilingual / Mixed",
        lang_unknown: "Unknown"
    }
};

const PRESETS = {
    vodafone_cash: "مبروك كسبت 50000 جنيه من فودافون كاش! دوس ع اللينك واستلم فلوسك فورا قبل ما العرض ينتهي: http://voda-cash-win.xyz/claim",
    instapay_threat: "عميلنا العزيز، تم ايقاف محفظتك الذكية في انستاباي بسبب عدم تحديث البيانات. لتجنب الحظر النهائي ادخل هنا وحدث بياناتك: http://instapay-security-portal.top/login",
    banquemisr_phish: "خدمه عملاء بنك مصر: مطلوب فورا تحديث بطاقتك الائتمانية قبل الساعه 6 مساء عشان حسابك هيقف نهائيا. ادخل اللينك: http://banquemisr-online.xyz/update",
    paypal_en: "URGENT: Your PayPal account has been temporarily restricted due to unauthorized login attempts. Verify your identity now to avoid permanent suspension: https://paypal-security-account.top/verify",
    legit_otp: "انستاباي: رمز التأكيد السري الخاص بك لتسجيل الدخول هو 749281. تحذير: لا تشارك هذا الرمز مع أي شخص حتى موظفي البنك.",
    legit_bank_sms: "البنك الأهلي المصري: تم سحب مبلغ 500 جنيه من ماكينة صراف آلي برقم بطاقة تنتهي بـ 4920. الرصيد المتاح 18,400 جنيه.",
    suspicious_url: "http://192.168.1.104/vodafone-cash/login.php"
};

let currentLang = 'ar';
let lastAnalysisId = null;

// DOM Elements
const langToggleBtn = document.getElementById('langToggleBtn');
const messageInput = document.getElementById('messageInput');
const charCount = document.getElementById('charCount');
const analyzeBtn = document.getElementById('analyzeBtn');
const clearBtn = document.getElementById('clearBtn');
const scannerOverlay = document.getElementById('scannerOverlay');

const resultsCard = document.getElementById('resultsCard');
const resultsContent = document.getElementById('resultsContent');

// Verdict Banner elements
const verdictBanner = document.getElementById('verdictBanner');
const verdictBadge = document.getElementById('verdictBadge');
const verdictIcon = document.getElementById('verdictIcon');
const verdictTitle = document.getElementById('verdictTitle');
const verdictSummary = document.getElementById('verdictSummary');
const latencyBadge = document.getElementById('latencyBadge');
const gaugeValue = document.getElementById('gaugeValue');
const gaugeProgressCircle = document.getElementById('gaugeProgressCircle');
const confidenceValue = document.getElementById('confidenceValue');

// Engines elements
const textScorePill = document.getElementById('textScorePill');
const detectedLangBadge = document.getElementById('detectedLangBadge');
const textMlProbVal = document.getElementById('textMlProbVal');
const textHeuristicVal = document.getElementById('textHeuristicVal');
const triggerKeywordsContainer = document.getElementById('triggerKeywordsContainer');

const urlScorePill = document.getElementById('urlScorePill');
const extractedUrlCount = document.getElementById('extractedUrlCount');
const urlListContainer = document.getElementById('urlListContainer');

// Factors & Recommendations
const factorsListContainer = document.getElementById('factorsListContainer');
const recommendationsList = document.getElementById('recommendationsList');

// Feedback elements
const fbCorrectBtn = document.getElementById('fbCorrectBtn');
const fbFalsePositiveBtn = document.getElementById('fbFalsePositiveBtn');
const fbFalseNegativeBtn = document.getElementById('fbFalseNegativeBtn');
const feedbackThanksMsg = document.getElementById('feedbackThanksMsg');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setupLocalization();
    setupNavigation();
    setupPresets();
    setupInputListeners();
    setupFeedback();
    loadStats();
    loadModelsAndDatasets();
    loadHistory();
});

// Localization
function setupLocalization() {
    langToggleBtn.addEventListener('click', () => {
        currentLang = currentLang === 'ar' ? 'en' : 'ar';
        document.documentElement.lang = currentLang;
        document.documentElement.dir = currentLang === 'ar' ? 'rtl' : 'ltr';
        langToggleBtn.querySelector('.lang-code').textContent = currentLang === 'ar' ? 'EN' : 'عربي';

        // Update all text elements
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (I18N[currentLang][key]) {
                const span = el.querySelector('span');
                if (span) {
                    span.textContent = I18N[currentLang][key];
                } else {
                    el.textContent = I18N[currentLang][key];
                }
            }
        });

        // Update placeholder
        if (currentLang === 'ar') {
            messageInput.placeholder = "أدخل نص الرسالة (مصرية، عربية فصحى، إنجليزية) أو رابط URL هنا للفحص الدقيق...";
        } else {
            messageInput.placeholder = "Enter message text (Egyptian, MSA, English) or target URL here for deep inspection...";
        }
    });
}

// Navigation Tabs
function setupNavigation() {
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

            btn.classList.add('active');
            const targetId = `tab-${btn.getAttribute('data-tab')}`;
            const targetTab = document.getElementById(targetId);
            if (targetTab) {
                targetTab.classList.add('active');
            }

            if (btn.getAttribute('data-tab') === 'metrics') {
                loadModelsAndDatasets();
            } else if (btn.getAttribute('data-tab') === 'history') {
                loadHistory();
            }
        });
    });

    document.getElementById('refreshHistoryBtn').addEventListener('click', loadHistory);
    document.getElementById('retrainModelsBtn').addEventListener('click', handleRetrain);
}

// Input Handlers & Presets
function setupInputListeners() {
    messageInput.addEventListener('input', () => {
        charCount.textContent = messageInput.value.length;
    });

    clearBtn.addEventListener('click', () => {
        messageInput.value = '';
        charCount.textContent = '0';
        resultsCard.classList.add('empty-state');
        resultsContent.classList.add('hidden');
    });

    analyzeBtn.addEventListener('click', executeAnalysis);
}

function setupPresets() {
    document.querySelectorAll('.preset-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            const presetKey = chip.getAttribute('data-preset');
            if (PRESETS[presetKey]) {
                messageInput.value = PRESETS[presetKey];
                charCount.textContent = messageInput.value.length;
                executeAnalysis();
            }
        });
    });
}

// Analysis API Call & Result Rendering
async function executeAnalysis() {
    const text = messageInput.value.trim();
    if (!text) {
        alert(currentLang === 'ar' ? 'الرجاء إدخال نص أو رابط أولاً' : 'Please enter text or a URL first');
        return;
    }

    // Start scanning state
    analyzeBtn.disabled = true;
    scannerOverlay.classList.add('scanning');

    try {
        const response = await fetch('/api/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text })
        });

        if (!response.ok) {
            throw new Error(`Server returned status ${response.status}`);
        }

        const data = await response.json();
        renderAnalysisResults(data);
        loadStats(); // Update dashboard counts
    } catch (err) {
        console.error('Analysis error:', err);
        alert(currentLang === 'ar' ? `حدث خطأ أثناء الفحص: ${err.message}` : `Analysis error: ${err.message}`);
    } finally {
        analyzeBtn.disabled = false;
        scannerOverlay.classList.remove('scanning');
    }
}

function renderAnalysisResults(data) {
    lastAnalysisId = data.id;
    resultsCard.classList.remove('empty-state');
    resultsContent.classList.remove('hidden');
    feedbackThanksMsg.classList.add('hidden');

    const isPhishing = data.verdict === 'Phishing';
    const isSuspicious = data.verdict === 'Suspicious';
    const isSafe = data.verdict === 'Safe';

    // 1. Verdict Banner Style
    verdictBanner.className = 'verdict-banner';
    if (isPhishing) {
        verdictBanner.classList.add('verdict-phishing');
        verdictBadge.textContent = data.risk_level;
        verdictBadge.style.color = '#ff3366';
        verdictBadge.style.background = 'rgba(255, 51, 102, 0.15)';
        verdictTitle.textContent = currentLang === 'ar' ? I18N.ar.verdict_phishing : I18N.en.verdict_phishing;
        verdictIcon.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="#ff3366" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
        gaugeProgressCircle.style.stroke = '#ff3366';
    } else if (isSuspicious) {
        verdictBanner.classList.add('verdict-suspicious');
        verdictBadge.textContent = data.risk_level;
        verdictBadge.style.color = '#f59e0b';
        verdictBadge.style.background = 'rgba(245, 158, 11, 0.15)';
        verdictTitle.textContent = currentLang === 'ar' ? I18N.ar.verdict_suspicious : I18N.en.verdict_suspicious;
        verdictIcon.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
        gaugeProgressCircle.style.stroke = '#f59e0b';
    } else {
        verdictBanner.classList.add('verdict-safe');
        verdictBadge.textContent = 'SAFE';
        verdictBadge.style.color = '#10b981';
        verdictBadge.style.background = 'rgba(16, 185, 129, 0.15)';
        verdictTitle.textContent = currentLang === 'ar' ? I18N.ar.verdict_safe : I18N.en.verdict_safe;
        verdictIcon.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>`;
        gaugeProgressCircle.style.stroke = '#10b981';
    }

    latencyBadge.textContent = `${data.processing_time_ms} ms`;
    verdictSummary.textContent = currentLang === 'ar'
        ? `تقييم المخاطر المدمج: ${data.risk_percentage}% (مستوى الثقة: ${data.confidence_percentage}%)`
        : `Consolidated Threat Score: ${data.risk_percentage}% (Confidence: ${data.confidence_percentage}%)`;

    // 2. Animated Gauge
    gaugeValue.textContent = `${data.risk_percentage}%`;
    const circumference = 264;
    const offset = circumference - (data.final_risk_score * circumference);
    gaugeProgressCircle.style.strokeDashoffset = offset;
    confidenceValue.textContent = `${data.confidence_percentage}%`;

    // 3. Engine 1: Text Engine
    const textRisk = data.text_risk_score !== null ? `${Math.round(data.text_risk_score * 100)}%` : 'N/A';
    textScorePill.textContent = `${currentLang === 'ar' ? 'خطر' : 'Risk'}: ${textRisk}`;
    const langKey = `lang_${data.detected_language || 'unknown'}`;
    detectedLangBadge.textContent = I18N[currentLang][langKey] || data.detected_language;

    textMlProbVal.textContent = data.engines?.text_engine?.ml_probability !== null 
        ? `${Math.round((data.engines.text_engine.ml_probability || 0) * 100)}%` : 'N/A';
    textHeuristicVal.textContent = data.engines?.text_engine?.heuristic_score !== null 
        ? `${Math.round((data.engines.text_engine.heuristic_score || 0) * 100)}%` : 'N/A';

    triggerKeywordsContainer.innerHTML = '';
    const keywords = data.engines?.text_engine?.top_keywords || [];
    if (keywords.length > 0) {
        keywords.forEach(kw => {
            const chip = document.createElement('span');
            chip.className = 'keyword-chip';
            chip.textContent = kw;
            triggerKeywordsContainer.appendChild(chip);
        });
    } else {
        triggerKeywordsContainer.innerHTML = `<span style="font-size:0.75rem; color:var(--text-muted);">${currentLang === 'ar' ? 'لا توجد كلمات مشبوهة بارزة' : 'No prominent trigger tokens'}</span>`;
    }

    // 4. Engine 2: URL Engine
    const urlRisk = data.url_risk_score !== null ? `${Math.round(data.url_risk_score * 100)}%` : 'N/A';
    urlScorePill.textContent = `${currentLang === 'ar' ? 'خطر' : 'Risk'}: ${urlRisk}`;
    extractedUrlCount.textContent = data.extracted_urls?.length || 0;

    urlListContainer.innerHTML = '';
    const urlDetails = data.engines?.url_engine?.details || [];
    if (urlDetails.length > 0) {
        urlDetails.forEach(u => {
            const div = document.createElement('div');
            div.className = `url-item ${u.url_risk_score >= 0.6 ? 'high-risk' : ''}`;
            div.innerHTML = `
                <span class="url-text-truncate" title="${u.url}">${u.url}</span>
                <div style="display:flex; justify-content:space-between; margin-top:4px; font-size:0.7rem;">
                    <span>Host: <strong>${u.hostname || 'Direct IP'}</strong></span>
                    <span>Risk: <strong>${Math.round(u.url_risk_score * 100)}%</strong></span>
                </div>
            `;
            urlListContainer.appendChild(div);
        });
    } else {
        urlListContainer.innerHTML = `<span style="font-size:0.75rem; color:var(--text-muted);">${currentLang === 'ar' ? 'لم يتم رصد أي روابط في هذا النص' : 'No URLs extracted from message'}</span>`;
    }

    // 5. Explainable Factors (XAI)
    factorsListContainer.innerHTML = '';
    const factors = data.explanation_factors || [];
    if (factors.length > 0) {
        factors.forEach(f => {
            const item = document.createElement('div');
            item.className = 'factor-item';
            const desc = currentLang === 'ar' ? (f.description_ar || f.description_en) : (f.description_en || f.description_ar);
            item.innerHTML = `
                <span class="factor-badge sev-${f.severity || 'INFO'}">${f.severity || 'INFO'}</span>
                <span class="factor-desc">${desc}</span>
            `;
            factorsListContainer.appendChild(item);
        });
    } else {
        factorsListContainer.innerHTML = `<div class="factor-item"><span class="factor-badge sev-INFO">INFO</span><span class="factor-desc">${currentLang === 'ar' ? 'فحص سليم - الرسالة خالية من الأنماط الاستدراجية' : 'Clean verification - no deceptive lures found'}</span></div>`;
    }

    // 6. Actionable Recommendations
    recommendationsList.innerHTML = '';
    const recs = currentLang === 'ar' ? (data.recommendations?.ar || []) : (data.recommendations?.en || []);
    recs.forEach(r => {
        const li = document.createElement('li');
        li.textContent = r;
        recommendationsList.appendChild(li);
    });
}

// Human-in-the-Loop Feedback
function setupFeedback() {
    fbCorrectBtn.addEventListener('click', () => sendFeedback('correct'));
    fbFalsePositiveBtn.addEventListener('click', () => sendFeedback('false_positive'));
    fbFalseNegativeBtn.addEventListener('click', () => sendFeedback('false_negative'));
}

async function sendFeedback(label) {
    if (!lastAnalysisId) return;

    try {
        const response = await fetch('/api/feedback', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                analysis_id: lastAnalysisId,
                actual_label: label === 'false_positive' ? 'legitimate' : (label === 'false_negative' ? 'phishing' : 'correct')
            })
        });

        if (response.ok) {
            feedbackThanksMsg.classList.remove('hidden');
            loadStats();
        }
    } catch (e) {
        console.error('Feedback submission error:', e);
    }
}

// Dashboard Stats
async function loadStats() {
    try {
        const res = await fetch('/api/stats');
        if (res.ok) {
            const stats = await res.json();
            document.getElementById('statTotalScans').textContent = stats.total_scans;
            document.getElementById('statPhishingDetected').textContent = stats.phishing_detected;
            document.getElementById('statSuspicious').textContent = stats.suspicious_flagged;
            document.getElementById('statSafeVerified').textContent = stats.safe_verified;
            document.getElementById('statAvgLatency').textContent = `${stats.avg_latency_ms} ms`;
        }
    } catch (e) {
        console.error('Stats loading error:', e);
    }
}

// Models & Datasets Tab
async function loadModelsAndDatasets() {
    try {
        const [modelsRes, datasetsRes] = await fetchAll(['/api/models', '/api/datasets']);
        
        // Render Model Cards
        const grid = document.getElementById('modelsGridContainer');
        grid.innerHTML = '';

        if (modelsRes && modelsRes.length > 0) {
            modelsRes.forEach(m => {
                const metrics = m.metrics || {};
                const cm = metrics.confusion_matrix || { tn: 0, fp: 0, fn: 0, tp: 0 };
                const card = document.createElement('div');
                card.className = 'model-card';
                card.innerHTML = `
                    <div class="model-card-header">
                        <div>
                            <h3 class="model-name">${m.model_name}</h3>
                            <span class="model-algo">${m.algorithm}</span>
                        </div>
                        ${m.is_active ? `<span class="model-active-badge">Active Production</span>` : ''}
                    </div>

                    <div class="metrics-row-grid">
                        <div class="metric-box">
                            <div class="metric-box-val">${Math.round((metrics.accuracy || 0) * 100)}%</div>
                            <div class="metric-box-lbl">Accuracy</div>
                        </div>
                        <div class="metric-box">
                            <div class="metric-box-val">${metrics.f1_score ? metrics.f1_score.toFixed(3) : 'N/A'}</div>
                            <div class="metric-box-lbl">F1-Score</div>
                        </div>
                        <div class="metric-box">
                            <div class="metric-box-val">${metrics.precision ? metrics.precision.toFixed(3) : 'N/A'}</div>
                            <div class="metric-box-lbl">Precision</div>
                        </div>
                        <div class="metric-box">
                            <div class="metric-box-val">${metrics.roc_auc ? metrics.roc_auc.toFixed(3) : 'N/A'}</div>
                            <div class="metric-box-lbl">ROC-AUC</div>
                        </div>
                    </div>

                    <div class="confusion-matrix-box">
                        <div class="cm-title">Confusion Matrix (Validation Test Split):</div>
                        <div class="cm-grid">
                            <div class="cm-cell">True Negatives (TN): <strong>${cm.tn}</strong></div>
                            <div class="cm-cell">False Positives (FP): <strong>${cm.fp}</strong></div>
                            <div class="cm-cell">False Negatives (FN): <strong>${cm.fn}</strong></div>
                            <div class="cm-cell">True Positives (TP): <strong>${cm.tp}</strong></div>
                        </div>
                    </div>
                `;
                grid.appendChild(card);
            });
        }

        // Render Datasets Table
        const tbody = document.querySelector('#datasetsTable tbody');
        tbody.innerHTML = '';
        if (datasetsRes && datasetsRes.length > 0) {
            datasetsRes.forEach(d => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td><strong>${d.name}</strong></td>
                    <td>${d.dialect_or_lang}</td>
                    <td><span class="highlight-cyan">${d.sample_count}</span></td>
                    <td style="font-size:0.8rem; color:var(--text-secondary);">${d.source_description}</td>
                    <td style="font-size:0.75rem; font-family:var(--font-mono);">${d.created_at?.slice(0, 10)}</td>
                `;
                tbody.appendChild(tr);
            });
        }
    } catch (e) {
        console.error('Error loading models/datasets:', e);
    }
}

async function handleRetrain() {
    const btn = document.getElementById('retrainModelsBtn');
    btn.disabled = true;
    const oldText = btn.innerHTML;
    btn.innerHTML = `<span>جاري التدريب والتقييم...</span>`;

    try {
        const res = await fetch('/api/retrain', { method: 'POST' });
        if (res.ok) {
            alert(currentLang === 'ar' ? 'تمت إعادة تدريب النماذج بنجاح وتسجيل المقاييس الجديدة!' : 'Models retrained successfully with new benchmark metrics!');
            loadModelsAndDatasets();
        }
    } catch (e) {
        alert('Retrain error: ' + e.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = oldText;
    }
}

// History & Audit Logs Tab
async function loadHistory() {
    try {
        const res = await fetch('/api/history?limit=30');
        if (res.ok) {
            const logs = await res.json();
            const tbody = document.getElementById('historyTableBody');
            tbody.innerHTML = '';

            if (logs.length === 0) {
                tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color:var(--text-muted); padding:20px;">لا توجد سجلات بعد</td></tr>`;
                return;
            }

            logs.forEach(item => {
                const tr = document.createElement('tr');
                const timeStr = item.created_at ? item.created_at.slice(11, 19) : '-';
                const isPhish = item.verdict === 'Phishing';
                const isSafe = item.verdict === 'Safe';
                const color = isPhish ? 'var(--threat-red)' : (isSafe ? 'var(--safe-green)' : 'var(--warn-amber)');

                tr.innerHTML = `
                    <td style="font-family:var(--font-mono); color:var(--text-muted);">${item.id}</td>
                    <td style="font-family:var(--font-mono); font-size:0.75rem;">${timeStr}</td>
                    <td><span style="font-size:0.72rem; padding:2px 6px; border-radius:4px; background:rgba(255,255,255,0.06);">${item.input_type}</span></td>
                    <td style="max-width:280px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:0.82rem;" title="${item.raw_text || ''}">${item.raw_text || '-'}</td>
                    <td><span style="font-size:0.75rem; color:var(--cyan-accent);">${item.detected_language}</span></td>
                    <td><strong style="color:${color};">${item.verdict}</strong></td>
                    <td style="font-family:var(--font-mono);">${Math.round((item.final_risk_score || 0) * 100)}%</td>
                    <td style="font-size:0.75rem;">${item.user_feedback || '<span style="color:var(--text-muted);">لم يُسجل</span>'}</td>
                `;
                tbody.appendChild(tr);
            });
        }
    } catch (e) {
        console.error('History load error:', e);
    }
}

async function fetchAll(urls) {
    return Promise.all(urls.map(u => fetch(u).then(r => r.json())));
}
