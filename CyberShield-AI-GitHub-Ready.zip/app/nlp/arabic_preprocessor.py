import re
from typing import Tuple, Dict, Any, List

# Arabic diacritics unicode range
DIACRITICS_REGEX = re.compile(r'[\u064B-\u0652\u0653-\u0655\u0670]')
TATWEEL_REGEX = re.compile(r'\u0640')

# Egyptian dialect markers & common colloquial phishing tokens
EGYPTIAN_COLLOQUIAL_TERMS = {
    "كسبت", "فزت", "الحق", "دوس", "عشان", "عشانك", "هنوقف", "هنقفل", "هيتوقف", 
    "حيتقفل", "ع اللينك", "عاللينك", "عالرابط", "ع الرابط", "ابعث", "ابعت", 
    "فودافون", "اورنج", "اتصالات", "وي", "انستاباي", "انستا باي", "كاش", 
    "الاهلي", "بنك مصر", "فيزا", "كارت", "كود السحب", "مبروك عليك", "جنيه", 
    "ج.م", "شحنة", "شحنتك", "كود التحقق", "محدش يشاركه", "هديه", "سحب عشوائي",
    "فلوس", "يا فندم", "يا باشا", "خدمه العملاء", "مفيش وقت", "عرض انهارده"
}

# High-risk urgency / threat / bait triggers across Arabic & Egyptian dialect
SUSPICIOUS_ARABIC_PATTERNS = [
    (r'(تم\s*(إيقاف|تجميد|حظر|تعليق|حسابك\s*معلق)\s*(حسابك|بطاقتك|محفظتك)?)', 2.5, "تنبيه إيقاف أو تجميد حساب/محفظة"),
    (r'(تحديث\s*(البيانات|بياناتك|الهوية|الحساب|بطاقتك))', 2.2, "طلب لتحديث بيانات بنكية أو بطاقة"),
    (r'(مبروك\s*(كسبت|فزت|ربحت))', 2.4, "إغراء جوائز وهمية ومسابقات احتيالية"),
    (r'(فودافون\s*كاش|انستاباي|انستا\s*باي|محفظة\s*ذكية).*(كسبت|فزت|ايقاف|تحديث|حظر|رابط|لينك|كود|سحب|هدية|استلم|فلوس)', 2.2, "استخدام محفظة إلكترونية مقترناً باستدراج احتيالي"),
    (r'(كود\s*(التحقق|التأكيد|OTP|السر|السري|السحب))', 1.8, "إشارة لكود التحقق السري (OTP)"),
    (r'(دوس\s*(ع\s*اللينك|عاللينك|هنا)|اضغط\s*(هنا|ع\s*الرابط|عالرابط|عاللينك|ع\s*اللينك))', 2.2, "حث مباشر ومكثف للضغط على رابط"),
    (r'(شحنتك\s*(معلقة|في الانتظار|لم تسلم)|سداد\s*(رسوم|مصاريف))', 2.0, "انتحال شركات الشحن والطرود"),
    (r'(فرصة\s*(أخيرة|محدودة|لن تتكرر)|ساعات\s*قليلة\s*متبقية)', 1.5, "خلق شعور وهمي بالعجلة والضغط الزمني")
]

# Legitimate safety signals (reduce false positive risk)
LEGITIMATE_SAFETY_PATTERNS = [
    (r'(لا\s*(تشارك|تفصح|تعط)\s*(هذا\s*الرمز|الكود|كلمة\s*السر|الرقم\s*السري))', 2.0, "تحذير رسمي بعدم مشاركة الرمز السري"),
    (r'(تم\s*(تحويل|سحب|إيداع)\s*مبلغ.*(رصيدك\s*الحالي|الرصيد\s*المتاح))', 2.0, "إشعار معاملة بنكية رسمية برصيد حساب"),
    (r'(don\'t\s*share\s*this\s*code|never\s*share|our\s*employees\s*will\s*never\s*ask)', 2.0, "Official safety instruction not to share OTP")
]


# High-risk English patterns
SUSPICIOUS_ENGLISH_PATTERNS = [
    (r'(account\s*(suspended|locked|disabled|blocked|compromised))', 2.5, "Account suspension/blocking threat"),
    (r'(verify\s*your\s*(account|identity|credentials|card|wallet))', 2.2, "Urgent account/identity verification request"),
    (r'(you\s*(won|have\s*been\s*selected|are\s*the\s*lucky\s*winner))', 2.2, "Fake lottery/reward prize hook"),
    (r'(unauthorized\s*(login|activity|transaction|access))', 2.4, "Scare tactic regarding unauthorized access"),
    (r'(immediate\s*action\s*required|urgent\s*notice|within\s*24\s*hours)', 1.8, "Artificial urgency urgency trigger"),
    (r'(click\s*(here|on\s*the\s*link|below)|login\s*now|claim\s*now)', 1.7, "Direct call to action to external link"),
    (r'(refund\s*(pending|approved|available)|parcel\s*(delayed|delivery|hold))', 2.0, "Delivery/refund lure")
]

def normalize_arabic(text: str) -> str:
    """
    Comprehensive normalization for Classical & Egyptian Arabic text.
    Handles letter variants, diacritics, tatweel, and common colloquial spellings.
    """
    if not text:
        return ""
    
    # Remove diacritics (tashkeel)
    text = DIACRITICS_REGEX.sub('', text)
    
    # Remove tatweel (kashida)
    text = TATWEEL_REGEX.sub('', text)
    
    # Normalize Alif forms (إ, أ, آ, ٱ -> ا)
    text = re.sub(r'[إأآٱ]', 'ا', text)
    
    # Normalize Yaa forms (ى -> ي)
    text = re.sub(r'ى\b', 'ي', text)
    
    # Normalize Taa Marbuta (ة -> ه) for robust matching in informal writing
    text = re.sub(r'ة\b', 'ه', text)
    
    # Normalize repeated letters (e.g. مبروووووك -> مبروك, دوسسسس -> دوس)
    text = re.sub(r'(.)\1{2,}', r'\1\1', text)
    
    # Normalize whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

def detect_language(text: str) -> Dict[str, Any]:
    """
    Detects language and dialect (Egyptian Arabic 'arz', Modern Standard Arabic 'ar', English 'en', or 'mixed').
    """
    if not text:
        return {"language": "unknown", "is_egyptian": False, "ar_ratio": 0.0, "en_ratio": 0.0}

    arabic_chars = len(re.findall(r'[\u0600-\u06FF]', text))
    latin_chars = len(re.findall(r'[a-zA-Z]', text))
    total_letters = arabic_chars + latin_chars

    if total_letters == 0:
        return {"language": "unknown", "is_egyptian": False, "ar_ratio": 0.0, "en_ratio": 0.0}

    ar_ratio = arabic_chars / total_letters
    en_ratio = latin_chars / total_letters

    norm_text = normalize_arabic(text.lower())
    words = set(norm_text.split())
    egyptian_matches = words.intersection(EGYPTIAN_COLLOQUIAL_TERMS)
    has_egyptian_markers = len(egyptian_matches) > 0

    if ar_ratio > 0.65:
        lang = "arz" if has_egyptian_markers else "ar"
    elif en_ratio > 0.65:
        lang = "en"
    else:
        lang = "mixed"

    return {
        "language": lang,
        "is_egyptian": has_egyptian_markers,
        "egyptian_keywords_found": list(egyptian_matches),
        "ar_ratio": round(ar_ratio, 2),
        "en_ratio": round(en_ratio, 2)
    }

def analyze_linguistic_heuristics(text: str) -> Dict[str, Any]:
    """
    Extracts explicit linguistic phishing markers and psychological manipulation patterns
    (urgency, intimidation, greed/prizes, authority impersonation).
    """
    norm_text = normalize_arabic(text)
    lower_text = text.lower()
    
    detected_factors = []
    total_heuristic_score = 0.0

    # Arabic checks
    for pattern, weight, reason in SUSPICIOUS_ARABIC_PATTERNS:
        match = re.search(pattern, norm_text, re.IGNORECASE)
        if match:
            total_heuristic_score += weight
            detected_factors.append({
                "type": "linguistic_arabic",
                "matched_text": match.group(0),
                "severity": "HIGH" if weight >= 2.0 else "MEDIUM",
                "description_ar": reason,
                "description_en": f"Suspicious Arabic pattern: {reason}"
            })

    # English checks
    for pattern, weight, reason in SUSPICIOUS_ENGLISH_PATTERNS:
        match = re.search(pattern, lower_text, re.IGNORECASE)
        if match:
            total_heuristic_score += weight
            detected_factors.append({
                "type": "linguistic_english",
                "matched_text": match.group(0),
                "severity": "HIGH" if weight >= 2.0 else "MEDIUM",
                "description_ar": f"نمط تصيد إنجليزي مشبوه: {reason}",
                "description_en": reason
            })

    # Legitimate safety pattern check (dampen false positives on receipts/official OTPs)
    for pattern, damp_weight, reason in LEGITIMATE_SAFETY_PATTERNS:
        match = re.search(pattern, norm_text, re.IGNORECASE) or re.search(pattern, lower_text, re.IGNORECASE)
        if match:
            total_heuristic_score = max(0.0, total_heuristic_score - damp_weight)
            detected_factors.append({
                "type": "legitimate_safety_indicator",
                "matched_text": match.group(0),
                "severity": "INFO",
                "description_ar": f"مؤشر أمان رسمي: {reason}",
                "description_en": f"Official safety indicator: {reason}"
            })

    # Normalize heuristic score to [0.0, 1.0]
    normalized_score = min(total_heuristic_score / 6.0, 1.0)


    return {
        "linguistic_risk_score": round(normalized_score, 3),
        "factors": detected_factors
    }
