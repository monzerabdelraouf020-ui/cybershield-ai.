import os
import joblib
import numpy as np
from typing import Dict, Any, List, Optional
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import FeatureUnion

from app.config import MODELS_DIR
from app.nlp.arabic_preprocessor import normalize_arabic, detect_language, analyze_linguistic_heuristics

MODEL_PATH = MODELS_DIR / "text_phishing_model.joblib"
VECTORIZER_PATH = MODELS_DIR / "text_vectorizer.joblib"

class TextPhishingClassifier:
    def __init__(self):
        self.model: Optional[LogisticRegression] = None
        self.vectorizer: Optional[FeatureUnion] = None
        self.load()

    def load(self) -> bool:
        """Loads trained model & vectorizer from disk if present."""
        if MODEL_PATH.exists() and VECTORIZER_PATH.exists():
            try:
                self.model = joblib.load(MODEL_PATH)
                self.vectorizer = joblib.load(VECTORIZER_PATH)
                return True
            except Exception as e:
                print(f"[CyberShield TextClassifier] Error loading model: {e}")
        return False

    def train(self, texts: List[str], labels: List[int]) -> Dict[str, Any]:
        """
        Trains TF-IDF (word + char n-grams) + Logistic Regression pipeline.
        Optimized for 8GB RAM, highly accurate on morphological & dialectal variations.
        """
        # Preprocess all texts with Arabic normalization
        cleaned_texts = [normalize_arabic(t) for t in texts]

        # FeatureUnion combining word n-grams (1, 2) and char n-grams (3, 5)
        self.vectorizer = FeatureUnion([
            ('word_tfidf', TfidfVectorizer(
                ngram_range=(1, 2),
                min_df=1,
                sublinear_tf=True
            )),
            ('char_tfidf', TfidfVectorizer(
                analyzer='char',
                ngram_range=(3, 5),
                min_df=1,
                sublinear_tf=True
            ))
        ])

        X = self.vectorizer.fit_transform(cleaned_texts)
        y = np.array(labels)

        self.model = LogisticRegression(C=2.0, max_iter=1000, random_state=42)
        self.model.fit(X, y)

        # Save artifacts
        joblib.dump(self.model, MODEL_PATH)
        joblib.dump(self.vectorizer, VECTORIZER_PATH)

        return {"status": "trained", "samples": len(texts), "vocab_features": X.shape[1]}

    def predict(self, raw_text: str) -> Dict[str, Any]:
        """
        Predicts phishing likelihood for an incoming text with explainability breakdown.
        """
        if not raw_text or not raw_text.strip():
            return {
                "text_risk_score": 0.0,
                "confidence": 1.0,
                "detected_language": "unknown",
                "ml_probability": 0.0,
                "heuristic_score": 0.0,
                "top_keywords": [],
                "explanation_factors": []
            }

        lang_info = detect_language(raw_text)
        heuristics = analyze_linguistic_heuristics(raw_text)
        cleaned_text = normalize_arabic(raw_text)

        ml_prob = 0.5  # default neutral if model not yet loaded
        top_contributing_words = []

        if self.model and self.vectorizer:
            try:
                vec = self.vectorizer.transform([cleaned_text])
                probs = self.model.predict_proba(vec)[0]
                ml_prob = float(probs[1])  # Probability of class 1 (phishing)

                # Extract top contributing features (LIME/Coefficients explanation)
                feature_names = self.vectorizer.get_feature_names_out()
                coefs = self.model.coef_[0]
                non_zero_indices = vec.nonzero()[1]

                # Weight of each active feature in this input
                contributions = []
                for idx in non_zero_indices:
                    weight = coefs[idx] * vec[0, idx]
                    if weight > 0:  # Positively pushing towards Phishing
                        feat_name = feature_names[idx].split('__')[-1]
                        contributions.append((feat_name, float(weight)))

                contributions.sort(key=lambda x: x[1], reverse=True)
                top_contributing_words = [item[0] for item in contributions[:6]]
            except Exception as e:
                print(f"[CyberShield TextClassifier] Prediction exception: {e}")
                ml_prob = heuristics["linguistic_risk_score"]
        else:
            ml_prob = heuristics["linguistic_risk_score"]

        # Combined text score with heuristic boosting
        heuristic_score = heuristics["linguistic_risk_score"]
        
        # If strong linguistic threat detected, enforce minimum risk
        if heuristic_score >= 0.6:
            text_risk_score = max(ml_prob * 0.6 + heuristic_score * 0.4, heuristic_score)
        else:
            text_risk_score = ml_prob * 0.7 + heuristic_score * 0.3

        text_risk_score = min(max(text_risk_score, 0.0), 1.0)
        confidence = abs(text_risk_score - 0.5) * 2.0  # Distance from boundary [0, 1]

        # Consolidate explanation factors
        factors = list(heuristics["factors"])
        if top_contributing_words:
            factors.append({
                "type": "text_ml_ngrams",
                "severity": "HIGH" if text_risk_score > 0.6 else "MEDIUM",
                "description_ar": f"عبارات وكلمات تطابق أنماط التصيد المعروفة إحصائياً: {', '.join(top_contributing_words[:4])}",
                "description_en": f"N-grams highly correlated with phishing models: {', '.join(top_contributing_words[:4])}"
            })

        if lang_info["is_egyptian"]:
            factors.append({
                "type": "egyptian_dialect_markers",
                "severity": "INFO",
                "description_ar": f"تم التعرف على كلمات وعبارات دارجة باللهجة المصرية: {', '.join(lang_info['egyptian_keywords_found'])}",
                "description_en": f"Detected Egyptian colloquial keywords: {', '.join(lang_info['egyptian_keywords_found'])}"
            })

        return {
            "text_risk_score": round(text_risk_score, 3),
            "confidence": round(confidence, 3),
            "detected_language": lang_info["language"],
            "is_egyptian": lang_info["is_egyptian"],
            "ml_probability": round(ml_prob, 3),
            "heuristic_score": round(heuristic_score, 3),
            "top_keywords": top_contributing_words,
            "explanation_factors": factors
        }

# Global singleton
text_classifier = TextPhishingClassifier()
