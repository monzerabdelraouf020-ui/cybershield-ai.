import joblib
import numpy as np
from typing import Dict, Any, List, Optional
from sklearn.ensemble import RandomForestClassifier

from app.config import MODELS_DIR
from app.url.feature_extractor import extract_url_features
from app.url.url_extractor import extract_urls

URL_MODEL_PATH = MODELS_DIR / "url_phishing_model.joblib"
URL_FEATURE_KEYS = [
    "length_url", "length_domain", "length_path", "nb_dots", "nb_hyphens",
    "nb_at", "nb_qm", "nb_percent", "nb_slash", "nb_digits", "digit_ratio",
    "subdomain_count", "is_ip", "is_https", "has_port", "is_punycode",
    "entropy", "is_shortener", "is_suspicious_tld", "has_brand_lure",
    "has_sensitive_kw", "has_double_slash_path"
]

class URLPhishingClassifier:
    def __init__(self):
        self.model: Optional[RandomForestClassifier] = None
        self.load()

    def load(self) -> bool:
        """Loads trained URL model from disk if present."""
        if URL_MODEL_PATH.exists():
            try:
                self.model = joblib.load(URL_MODEL_PATH)
                return True
            except Exception as e:
                print(f"[CyberShield URLClassifier] Error loading model: {e}")
        return False

    def _features_to_vector(self, feat_dict: Dict[str, Any]) -> List[float]:
        return [float(feat_dict.get(k, 0)) for k in URL_FEATURE_KEYS]

    def train(self, urls: List[str], labels: List[int]) -> Dict[str, Any]:
        """
        Trains Random Forest classifier on URL structural and lexical features.
        """
        X = []
        for u in urls:
            res = extract_url_features(u)
            X.append(self._features_to_vector(res["features"]))

        X = np.array(X)
        y = np.array(labels)

        self.model = RandomForestClassifier(n_estimators=50, max_depth=8, random_state=42)
        self.model.fit(X, y)

        joblib.dump(self.model, URL_MODEL_PATH)
        return {"status": "trained", "samples": len(urls), "features_dim": len(URL_FEATURE_KEYS)}

    def analyze_single_url(self, url_str: str) -> Dict[str, Any]:
        """
        Analyzes a single URL using structural feature extraction + ML + heuristic rules.
        """
        feat_res = extract_url_features(url_str)
        heuristic_score = feat_res["heuristic_score"]
        factors = list(feat_res["factors"])

        ml_prob = heuristic_score  # default to heuristics
        if self.model:
            try:
                vec = np.array([self._features_to_vector(feat_res["features"])])
                probs = self.model.predict_proba(vec)[0]
                ml_prob = float(probs[1])
            except Exception as e:
                print(f"[CyberShield URLClassifier] ML predict error: {e}")

        # Combine ML probability and Heuristic rules
        # If IP host or Punycode or fake brand detected, enforce high score
        if feat_res["features"]["is_ip"] or feat_res["features"]["is_punycode"]:
            final_url_score = max(0.95, ml_prob)
        elif feat_res["features"]["has_brand_lure"] and feat_res["features"]["is_suspicious_tld"]:
            final_url_score = max(0.90, ml_prob)
        else:
            final_url_score = (ml_prob * 0.6) + (heuristic_score * 0.4)

        final_url_score = min(max(final_url_score, 0.0), 1.0)

        return {
            "url": url_str,
            "hostname": feat_res["hostname"],
            "url_risk_score": round(final_url_score, 3),
            "ml_probability": round(ml_prob, 3),
            "heuristic_score": round(heuristic_score, 3),
            "features": feat_res["features"],
            "factors": factors
        }

    def analyze_urls_in_text(self, text_or_url: str) -> Dict[str, Any]:
        """
        Extracts all URLs and analyzes them. Returns aggregated risk metrics.
        """
        urls = extract_urls(text_or_url)
        if not urls:
            return {
                "has_urls": False,
                "url_count": 0,
                "urls_found": [],
                "max_url_risk": 0.0,
                "url_details": [],
                "explanation_factors": []
            }

        url_details = [self.analyze_single_url(u) for u in urls]
        max_score = max(item["url_risk_score"] for item in url_details)

        # Merge all URL factors
        all_factors = []
        for item in url_details:
            for factor in item["factors"]:
                factor_copy = dict(factor)
                factor_copy["source_url"] = item["url"]
                all_factors.append(factor_copy)

        return {
            "has_urls": True,
            "url_count": len(urls),
            "urls_found": urls,
            "max_url_risk": max_score,
            "url_details": url_details,
            "explanation_factors": all_factors
        }

# Global singleton
url_classifier = URLPhishingClassifier()
