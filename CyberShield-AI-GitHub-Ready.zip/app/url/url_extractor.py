import re
from typing import List
from urllib.parse import urlparse

# Regex for matching URLs with or without http/https prefix (supports domain names and IP addresses)
URL_PATTERN = re.compile(
    r'(?:(?:https?|ftp):\/\/)?'  # optional scheme
    r'(?:(?:[a-zA-Z0-9_\-\.]+\.[a-zA-Z]{2,})|(?:\d{1,3}(?:\.\d{1,3}){3}))'  # domain or IPv4
    r'(?::\d{1,5})?'  # optional port
    r'(?:\/[^\s\(\)\[\]\{\}\<\>\"\']*)?',  # path and query
    re.IGNORECASE
)


def extract_urls(text: str) -> List[str]:
    """
    Extracts all URLs and domain references from raw text.
    Filters out obvious false positives like email address domains and file extensions.
    """
    if not text:
        return []
    
    matches = URL_PATTERN.findall(text)
    clean_urls = []
    
    for match in matches:
        m = match.strip(".,;:!?()[]{}'\"")
        # Ensure it has a dot and looks like a valid URL or host
        if "." in m and len(m) > 4:
            # Skip if it's purely a standard decimal number like 3.14
            if re.match(r'^\d+\.\d+$', m):
                continue
            # Prepend https:// if scheme is missing for standard parsing
            if not m.startswith(("http://", "https://", "ftp://")):
                m = "https://" + m
            if m not in clean_urls:
                clean_urls.append(m)
                
    return clean_urls
