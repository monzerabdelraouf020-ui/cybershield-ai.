import math
import re
from urllib.parse import urlparse
from typing import Dict, Any, List

# Known URL shortener domains
SHORTENER_DOMAINS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
    "adf.ly", "bit.do", "cutt.ly", "rb.gy", "rebrand.ly", "shorturl.at", "tiny.cc"
}

# Suspicious / Cheap / Abused TLDs commonly used in phishing campaigns
SUSPICIOUS_TLDS = {
    "xyz", "top", "tk", "ml", "ga", "cf", "gq", "buzz", "work", "click", 
    "rest", "icu", "club", "monster", "online", "surf", "fit", "sbs", "cfd"
}

# Targeted brands in Egypt / Middle East and Global services
KNOWN_BRANDS = [
    "vodafone", "orange", "etisalat", "we", "instapay", "fawry", "cib", 
    "nbe", "banquemisr", "qnb", "alexbank", "paypal", "apple", "google", 
    "microsoft", "netflix", "amazon", "facebook", "whatsapp", "telegram",
    "carrefour", "noon", "jumia", "binance", "metamask", "dhl", "aramex", "bosta"
]

# Sensitive phishing action keywords
SENSITIVE_KEYWORDS = [
    "login", "signin", "verify", "verification", "secure", "security", 
    "account", "update", "banking", "wallet", "claim", "bonus", "free", 
    "prize", "gift", "confirm", "password", "otp", "billing", "recharge",
    "fawrypay", "transfer", "suspend", "unlock", "activation"
]

def calculate_shannon_entropy(string: str) -> float:
    """Calculates Shannon entropy of a given string (measures randomness)."""
    if not string:
        return 0.0
    probabilities = [float(string.count(c)) / len(string) for c in set(string)]
    return -sum(p * math.log2(p) for p in probabilities)

def extract_url_features(url_string: str) -> Dict[str, Any]:
    """
    Extracts 20+ academic phishing features from a single URL.
    Returns both numerical feature vector and human-readable explanation factors.
    """
    url_str = url_string.strip()
    if not url_str.startswith(("http://", "https://", "ftp://")):
        url_str = "https://" + url_str

    try:
        parsed = urlparse(url_str)
        hostname = (parsed.hostname or "").lower()
        path = parsed.path or ""
        query = parsed.query or ""
    except Exception:
        hostname = ""
        path = ""
        query = ""

    # Lexical features
    length_url = len(url_str)
    length_domain = len(hostname)
    length_path = len(path)
    nb_dots = url_str.count('.')
    nb_hyphens = hostname.count('-')
    nb_at = url_str.count('@')
    nb_qm = url_str.count('?')
    nb_percent = url_str.count('%')
    nb_slash = url_str.count('/')
    nb_digits = sum(c.isdigit() for c in url_str)
    digit_ratio = nb_digits / max(len(url_str), 1)

    # Subdomain count
    domain_parts = hostname.split('.')
    subdomain_count = max(0, len(domain_parts) - 2) if len(domain_parts) >= 2 else 0

    # IP address check in hostname
    is_ip = 1 if re.match(r'^(?:\d{1,3}\.){3}\d{1,3}$', hostname) else 0

    # HTTPS check
    is_https = 1 if url_str.startswith("https://") else 0

    # Non-standard port
    has_port = 1 if (parsed.port and parsed.port not in [80, 443]) else 0

    # Punycode / IDN Homograph check
    is_punycode = 1 if "xn--" in hostname else 0

    # Domain entropy
    entropy = calculate_shannon_entropy(hostname)

    # Shortener check
    is_shortener = 1 if any(shortener in hostname for shortener in SHORTENER_DOMAINS) else 0

    # Suspicious TLD check
    tld = domain_parts[-1] if len(domain_parts) > 1 else ""
    is_suspicious_tld = 1 if tld in SUSPICIOUS_TLDS else 0

    # Brand lures found
    brands_found = [b for b in KNOWN_BRANDS if b in hostname or b in path.lower()]
    has_brand_lure = 1 if len(brands_found) > 0 else 0

    # Sensitive keywords found
    keywords_found = [kw for kw in SENSITIVE_KEYWORDS if kw in path.lower() or kw in query.lower() or kw in hostname]
    has_sensitive_kw = 1 if len(keywords_found) > 0 else 0

    # Redirection // in path
    has_double_slash_path = 1 if "//" in path else 0

    features = {
        "length_url": length_url,
        "length_domain": length_domain,
        "length_path": length_path,
        "nb_dots": nb_dots,
        "nb_hyphens": nb_hyphens,
        "nb_at": nb_at,
        "nb_qm": nb_qm,
        "nb_percent": nb_percent,
        "nb_slash": nb_slash,
        "nb_digits": nb_digits,
        "digit_ratio": round(digit_ratio, 3),
        "subdomain_count": subdomain_count,
        "is_ip": is_ip,
        "is_https": is_https,
        "has_port": has_port,
        "is_punycode": is_punycode,
        "entropy": round(entropy, 3),
        "is_shortener": is_shortener,
        "is_suspicious_tld": is_suspicious_tld,
        "has_brand_lure": has_brand_lure,
        "has_sensitive_kw": has_sensitive_kw,
        "has_double_slash_path": has_double_slash_path
    }

    # Human-readable factors
    explanation_factors = []
    heuristic_risk = 0.0

    if is_ip:
        heuristic_risk += 3.5
        explanation_factors.append({
            "type": "url_ip_host",
            "severity": "CRITICAL",
            "description_ar": "الرابط يستخدم عنوان IP مباشر بدلاً من اسم نطاق رسمي",
            "description_en": "URL uses a direct raw IP address instead of a recognized domain name"
        })

    if is_punycode:
        heuristic_risk += 3.0
        explanation_factors.append({
            "type": "url_homograph_attack",
            "severity": "CRITICAL",
            "description_ar": "رصد هجوم تماثل الحروف (IDN Homograph/Punycode) لانتحال موقع موثوق",
            "description_en": "IDN Homograph / Punycode detected mimicking a legitimate domain"
        })

    if is_shortener:
        heuristic_risk += 1.8
        explanation_factors.append({
            "type": "url_shortener",
            "severity": "MEDIUM",
            "description_ar": "استخدام خدمة تقصير روابط لإخفاء الوجهة الحقيقية للموقع",
            "description_en": f"URL shortener detected hiding target destination ({hostname})"
        })

    if is_suspicious_tld:
        heuristic_risk += 2.0
        explanation_factors.append({
            "type": "url_suspicious_tld",
            "severity": "HIGH",
            "description_ar": f"امتداد النطاق (.{tld}) مشهور باستخدامه في حملات التصيد الرخيصة والمشبوهة",
            "description_en": f"Top-level domain (.{tld}) has high abuse rate in malicious campaigns"
        })

    if has_brand_lure:
        # Check if it's the exact official brand domain or a fake one
        is_exact_brand = any(hostname == f"{b}.com" or hostname.endswith(f".{b}.com") or hostname == f"{b}.com.eg" or hostname.endswith(f".{b}.com.eg") for b in brands_found)
        if not is_exact_brand:
            heuristic_risk += 2.5
            explanation_factors.append({
                "type": "url_brand_impersonation",
                "severity": "HIGH",
                "description_ar": f"محاولة انتحال هوية علامة تجارية معروفة ({', '.join(brands_found)}) في نطاق غير رسمي",
                "description_en": f"Potential brand impersonation ({', '.join(brands_found)}) within an unofficial domain"
            })

    if has_sensitive_kw and len(keywords_found) >= 2:
        heuristic_risk += 1.5
        explanation_factors.append({
            "type": "url_credential_keywords",
            "severity": "HIGH",
            "description_ar": f"الرابط يحتوي على كلمات استدراج تسجيل دخول وبيانات حساسة: {', '.join(keywords_found[:3])}",
            "description_en": f"URL contains sensitive credentials/action keywords: {', '.join(keywords_found[:3])}"
        })

    if subdomain_count >= 3:
        heuristic_risk += 1.5
        explanation_factors.append({
            "type": "url_deep_subdomains",
            "severity": "MEDIUM",
            "description_ar": f"تعدد النطاقات الفرعية بشكل غير طبيعي ({subdomain_count} نطاقات فرعية)",
            "description_en": f"Abnormal number of subdomains ({subdomain_count}) attempting to mislead users"
        })

    if entropy > 4.2 and length_domain > 12:
        heuristic_risk += 1.2
        explanation_factors.append({
            "type": "url_high_entropy",
            "severity": "MEDIUM",
            "description_ar": "عشوائية عالية في أحرف النطاق (مؤشر نطاق تم إنشاؤه آلياً DGA)",
            "description_en": f"High domain entropy ({entropy}) indicating machine-generated DGA domain"
        })

    if not is_https:
        heuristic_risk += 0.8
        explanation_factors.append({
            "type": "url_no_https",
            "severity": "LOW",
            "description_ar": "الرابط يفتقر إلى بروتوكول التشفير الآمن HTTPS",
            "description_en": "URL lacks secure HTTPS protocol encryption"
        })

    # Normalized heuristic score [0, 1]
    norm_score = min(heuristic_risk / 6.0, 1.0)

    return {
        "url": url_string,
        "hostname": hostname,
        "features": features,
        "heuristic_score": round(norm_score, 3),
        "factors": explanation_factors
    }
