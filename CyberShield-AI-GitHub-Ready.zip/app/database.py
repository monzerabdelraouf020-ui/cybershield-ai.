import sqlite3
import json
from datetime import datetime
from typing import List, Dict, Any, Optional
from app.config import DB_PATH

def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    # 1. analyses table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS analyses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        input_type TEXT NOT NULL,
        raw_text TEXT,
        extracted_urls TEXT,
        detected_language TEXT,
        text_risk_score REAL,
        url_risk_score REAL,
        final_risk_score REAL NOT NULL,
        risk_level TEXT NOT NULL,
        verdict TEXT NOT NULL,
        confidence REAL NOT NULL,
        explanation_factors TEXT,
        processing_time_ms REAL,
        user_feedback TEXT
    );
    """)

    # 2. datasets table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS datasets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        dialect_or_lang TEXT NOT NULL,
        sample_count INTEGER NOT NULL,
        source_description TEXT,
        created_at TEXT NOT NULL,
        file_path TEXT
    );
    """)

    # 3. model_versions table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS model_versions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        model_name TEXT NOT NULL,
        target_type TEXT NOT NULL,
        algorithm TEXT NOT NULL,
        metrics TEXT NOT NULL,
        is_active INTEGER DEFAULT 1,
        created_at TEXT NOT NULL,
        artifact_path TEXT
    );
    """)

    # 4. feedback table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        analysis_id INTEGER,
        actual_label TEXT NOT NULL,
        user_comments TEXT,
        created_at TEXT NOT NULL,
        reviewed INTEGER DEFAULT 0,
        FOREIGN KEY (analysis_id) REFERENCES analyses (id) ON DELETE SET NULL
    );
    """)

    conn.commit()
    conn.close()

def insert_analysis(record: Dict[str, Any]) -> int:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO analyses (
            created_at, input_type, raw_text, extracted_urls,
            detected_language, text_risk_score, url_risk_score,
            final_risk_score, risk_level, verdict, confidence,
            explanation_factors, processing_time_ms, user_feedback
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        datetime.utcnow().isoformat(),
        record.get("input_type", "combined"),
        record.get("raw_text"),
        json.dumps(record.get("extracted_urls", [])),
        record.get("detected_language", "unknown"),
        record.get("text_risk_score"),
        record.get("url_risk_score"),
        record.get("final_risk_score", 0.0),
        record.get("risk_level", "SAFE"),
        record.get("verdict", "Safe"),
        record.get("confidence", 0.0),
        json.dumps(record.get("explanation_factors", [])),
        record.get("processing_time_ms", 0.0),
        record.get("user_feedback")
    ))
    new_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return new_id

def get_recent_analyses(limit: int = 50) -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM analyses ORDER BY id DESC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    results = []
    for r in rows:
        d = dict(r)
        try:
            d["extracted_urls"] = json.loads(d["extracted_urls"]) if d["extracted_urls"] else []
        except Exception:
            d["extracted_urls"] = []
        try:
            d["explanation_factors"] = json.loads(d["explanation_factors"]) if d["explanation_factors"] else []
        except Exception:
            d["explanation_factors"] = []
        results.append(d)
    conn.close()
    return results

def get_analysis_by_id(analysis_id: int) -> Optional[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM analyses WHERE id = ?", (analysis_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    try:
        d["extracted_urls"] = json.loads(d["extracted_urls"]) if d["extracted_urls"] else []
    except Exception:
        d["extracted_urls"] = []
    try:
        d["explanation_factors"] = json.loads(d["explanation_factors"]) if d["explanation_factors"] else []
    except Exception:
        d["explanation_factors"] = []
    return d

def save_feedback(analysis_id: int, actual_label: str, comments: Optional[str] = None) -> int:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO feedback (analysis_id, actual_label, user_comments, created_at)
        VALUES (?, ?, ?, ?)
    """, (analysis_id, actual_label, comments, datetime.utcnow().isoformat()))
    fb_id = cursor.lastrowid

    # Update analysis record feedback state
    cursor.execute("UPDATE analyses SET user_feedback = ? WHERE id = ?", (actual_label, analysis_id))
    conn.commit()
    conn.close()
    return fb_id

def record_model_version(name: str, target_type: str, algorithm: str, metrics: Dict[str, Any], artifact_path: str) -> int:
    conn = get_connection()
    cursor = conn.cursor()
    # Mark old models of same target_type as inactive
    cursor.execute("UPDATE model_versions SET is_active = 0 WHERE target_type = ?", (target_type,))
    cursor.execute("""
        INSERT INTO model_versions (model_name, target_type, algorithm, metrics, is_active, created_at, artifact_path)
        VALUES (?, ?, ?, ?, 1, ?, ?)
    """, (name, target_type, algorithm, json.dumps(metrics), datetime.utcnow().isoformat(), artifact_path))
    model_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return model_id

def get_model_versions() -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM model_versions ORDER BY id DESC")
    rows = cursor.fetchall()
    results = []
    for r in rows:
        d = dict(r)
        try:
            d["metrics"] = json.loads(d["metrics"])
        except Exception:
            pass
        results.append(d)
    conn.close()
    return results

def record_dataset_entry(name: str, dialect_or_lang: str, sample_count: int, source_desc: str, file_path: str = "") -> int:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO datasets (name, dialect_or_lang, sample_count, source_description, created_at, file_path)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (name, dialect_or_lang, sample_count, source_desc, datetime.utcnow().isoformat(), file_path))
    ds_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return ds_id

def get_datasets() -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM datasets ORDER BY id DESC")
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_dashboard_stats() -> Dict[str, Any]:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM analyses")
    total_scans = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM analyses WHERE verdict = 'Phishing'")
    phishing_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM analyses WHERE verdict = 'Suspicious'")
    suspicious_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM analyses WHERE verdict = 'Safe'")
    safe_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM feedback")
    feedback_count = cursor.fetchone()[0]

    cursor.execute("SELECT AVG(processing_time_ms) FROM analyses")
    avg_latency = cursor.fetchone()[0] or 0.0

    conn.close()
    return {
        "total_scans": total_scans,
        "phishing_detected": phishing_count,
        "suspicious_flagged": suspicious_count,
        "safe_verified": safe_count,
        "feedback_reports": feedback_count,
        "avg_latency_ms": round(avg_latency, 2)
    }
