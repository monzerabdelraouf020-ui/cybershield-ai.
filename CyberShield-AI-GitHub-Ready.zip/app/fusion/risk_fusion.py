import time
from typing import Dict, Any, List
from app.config import (
    THRESHOLD_SAFE,
    THRESHOLD_SUSPICIOUS,
    THRESHOLD_HIGH,
    WEIGHT_TEXT,
    WEIGHT_URL
)
from app.nlp.text_classifier import text_classifier
from app.url.url_classifier import url_classifier
from app.url.url_extractor import extract_urls

class RiskFusionEngine:
    def evaluate(self, raw_input: str) -> Dict[str, Any]:
        """
        Multilingual Risk Fusion Engine.
        Synthesizes text NLP analysis and URL feature analysis into a unified,
        explainable cyber threat verdict.
        """
        start_time = time.time()
        input_text = raw_input.strip()

        # Check if input is solely a URL
        detected_urls = extract_urls(input_text)
        is_url_only = False
        if len(detected_urls) == 1:
            clean_in = input_text.rstrip("/").lower()
            clean_url = detected_urls[0].rstrip("/").lower()
            clean_url_no_scheme = clean_url.replace("https://", "").replace("http://", "")
            if (clean_in == clean_url or 
                clean_in == clean_url_no_scheme or 
                clean_in == f"http://{clean_url_no_scheme}" or 
                clean_in == f"https://{clean_url_no_scheme}"):
                is_url_only = True

        # 1. Text Analysis
        text_result = text_classifier.predict(input_text)
        text_score = text_result["text_risk_score"]

        # 2. URL Analysis
        url_result = url_classifier.analyze_urls_in_text(input_text)
        has_urls = url_result["has_urls"]
        url_score = url_result["max_url_risk"] if has_urls else 0.0

        # 3. Dynamic Fusion Logic
        if is_url_only:
            input_type = "url_only"
            final_risk = url_score
            confidence = abs(url_score - 0.5) * 2.0
        elif not has_urls:
            input_type = "text_only"
            final_risk = text_score
            confidence = text_result["confidence"]
        else:
            input_type = "combined"
            # High-threat dominance: If link is critical malicious, threat remains high even if lure text is short
            if url_score >= 0.70:
                final_risk = max(url_score, (WEIGHT_TEXT * text_score) + (WEIGHT_URL * url_score))
            elif text_score >= 0.70:
                final_risk = max(text_score, (WEIGHT_TEXT * text_score) + (WEIGHT_URL * url_score))
            else:
                base_fused = (WEIGHT_TEXT * text_score) + (WEIGHT_URL * url_score)
                synergy_bonus = 0.12 if (text_score >= 0.35 and url_score >= 0.35) else 0.0
                final_risk = min(base_fused + synergy_bonus, 1.0)
            
            confidence = max(text_result["confidence"], abs(url_score - 0.5) * 2.0)

        final_risk = round(min(max(final_risk, 0.0), 1.0), 3)
        confidence = round(min(max(confidence, 0.4), 0.99), 3)

        # 4. Categorize Verdict & Risk Level
        if final_risk >= THRESHOLD_HIGH:
            verdict = "Phishing"
            risk_level = "CRITICAL" if final_risk >= 0.85 else "HIGH"
        elif final_risk >= THRESHOLD_SAFE:
            verdict = "Suspicious"
            risk_level = "MEDIUM" if final_risk >= THRESHOLD_SUSPICIOUS else "LOW_RISK"
        else:
            verdict = "Safe"
            risk_level = "SAFE"


        # 5. Aggregate and Sort Explanation Factors
        all_factors = []
        if has_urls:
            all_factors.extend(url_result["explanation_factors"])
        if input_type != "url_only":
            all_factors.extend(text_result["explanation_factors"])

        # Prioritize factors by severity
        severity_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
        all_factors.sort(key=lambda f: severity_rank.get(f.get("severity", "INFO"), 5))

        # 6. Actionable Security Recommendations
        recommendations = self._generate_recommendations(verdict, has_urls, text_result)

        elapsed_ms = round((time.time() - start_time) * 1000, 2)

        return {
            "input_type": input_type,
            "raw_text": input_text,
            "detected_language": text_result["detected_language"],
            "is_egyptian": text_result.get("is_egyptian", False),
            "verdict": verdict,
            "risk_level": risk_level,
            "final_risk_score": final_risk,
            "risk_percentage": int(final_risk * 100),
            "confidence": confidence,
            "confidence_percentage": int(confidence * 100),
            "text_risk_score": text_score if input_type != "url_only" else None,
            "url_risk_score": url_score if has_urls else None,
            "extracted_urls": url_result["urls_found"],
            "explanation_factors": all_factors,
            "recommendations": recommendations,
            "processing_time_ms": elapsed_ms,
            "engines": {
                "text_engine": {
                    "ml_probability": text_result.get("ml_probability"),
                    "heuristic_score": text_result.get("heuristic_score"),
                    "top_keywords": text_result.get("top_keywords", [])
                },
                "url_engine": {
                    "url_count": url_result.get("url_count", 0),
                    "details": url_result.get("url_details", [])
                }
            }
        }

    def _generate_recommendations(self, verdict: str, has_urls: bool, text_result: Dict[str, Any]) -> Dict[str, List[str]]:
        if verdict == "Phishing":
            return {
                "ar": [
                    "احذر تماماً: لا تضغط على أي رابط موجود في هذه الرسالة.",
                    "لا تشارك رمز التحقق السري (OTP) أو أرقام بطاقتك البنكية تحت أي ظرف.",
                    "قم بحظر المرسل فوراً وإبلاغ الجهات المعنية أو خدمة عملاء البنك الرسمي.",
                    "إذا قمت بإدخال بياناتك سابقاً، تواصل فوراً مع مصرفك لتجميد البطاقة وتغيير كلمات السر."
                ],
                "en": [
                    "CRITICAL: Do NOT click any links or download attachments in this message.",
                    "Never share OTP codes, passwords, or credit card CVV under any circumstances.",
                    "Block the sender immediately and report the message to the official service provider.",
                    "If credentials were submitted, contact your bank immediately to freeze the account."
                ]
            }
        elif verdict == "Suspicious":
            return {
                "ar": [
                    "توخَّ الحذر: الرسالة تحمل علامات مريبة أو لغة إلحاح وتخويف غير معتادة.",
                    "تحقق من هوية المرسل عبر القنوات الرسمية قبل اتخاذ أي إجراء.",
                    "تأكد من عنوان الموقع المكتوب بدقة ولا تعتمد على الروابط المختصرة."
                ],
                "en": [
                    "Exercise caution: Message shows subtle psychological urgency or questionable link indicators.",
                    "Verify the sender's identity through direct, official communication channels.",
                    "Inspect the destination URL carefully without submitting sensitive personal data."
                ]
            }
        else:
            return {
                "ar": [
                    "الرسالة تبدو آمنة ولم يتم رصد مؤشرات تصيد احتيالي معروفة.",
                    "يُنصح دائماً بالتأكد من عدم مشاركة كلمات المرور والرموز السرية."
                ],
                "en": [
                    "Message appears legitimate. No common phishing vectors or deceptive markers detected.",
                    "Standard cyber hygiene: Always ensure sensitive operations happen inside official apps."
                ]
            }

risk_fusion = RiskFusionEngine()
