import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
STATIC_DIR = BASE_DIR / "app" / "static"
DB_PATH = BASE_DIR / "cybershield.db"

# Ensure directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)
STATIC_DIR.mkdir(parents=True, exist_ok=True)

# Risk Thresholds
THRESHOLD_SAFE = 0.35
THRESHOLD_SUSPICIOUS = 0.65
THRESHOLD_HIGH = 0.70

# Feature weights in fusion
WEIGHT_TEXT = 0.55
WEIGHT_URL = 0.45

