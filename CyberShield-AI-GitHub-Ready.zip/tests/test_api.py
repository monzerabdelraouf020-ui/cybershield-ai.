import unittest
from starlette.testclient import TestClient
from app.main import app

class TestAPIEndpoints(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_health_endpoint(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["status"], "healthy")
        self.assertTrue(data["text_model_loaded"])
        self.assertTrue(data["url_model_loaded"])

    def test_analyze_phishing_endpoint(self):
        payload = {
            "text": "مبروك كسبت 50000 جنيه من فودافون كاش! دوس ع اللينك: http://voda-cash-win.xyz/claim"
        }
        response = self.client.post("/api/analyze", json=payload)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["verdict"], "Phishing")
        self.assertGreaterEqual(data["final_risk_score"], 0.70)
        self.assertIn("id", data)
        self.assertIn("explanation_factors", data)
        self.assertIn("recommendations", data)

    def test_analyze_safe_endpoint(self):
        payload = {
            "text": "انستاباي: رمز التأكيد السري الخاص بك لتسجيل الدخول هو 749281. تحذير: لا تشارك هذا الرمز مع أي شخص حتى موظفي البنك."
        }
        response = self.client.post("/api/analyze", json=payload)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["verdict"], "Safe")

    def test_history_endpoint(self):
        response = self.client.get("/api/history")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIsInstance(data, list)
        self.assertGreater(len(data), 0)

    def test_stats_endpoint(self):
        response = self.client.get("/api/stats")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("total_scans", data)
        self.assertIn("phishing_detected", data)

    def test_models_endpoint(self):
        response = self.client.get("/api/models")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIsInstance(data, list)
        self.assertGreater(len(data), 0)

    def test_datasets_endpoint(self):
        response = self.client.get("/api/datasets")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIsInstance(data, list)

    def test_feedback_endpoint(self):
        # First analyze
        res = self.client.post("/api/analyze", json={"text": "رسالة تجريبية للفيدباك http://test.com"})
        a_id = res.json()["id"]

        # Submit feedback
        fb_res = self.client.post("/api/feedback", json={
            "analysis_id": a_id,
            "actual_label": "phishing",
            "comments": "رصد صحيح وممتاز"
        })
        self.assertEqual(fb_res.status_code, 200)
        self.assertEqual(fb_res.json()["status"], "success")

    def test_index_page(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("CyberShield", response.text)

if __name__ == "__main__":
    unittest.main()
