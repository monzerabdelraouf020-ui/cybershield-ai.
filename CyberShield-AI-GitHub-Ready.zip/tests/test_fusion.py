import unittest
from app.database import init_db, insert_analysis, get_recent_analyses, save_feedback, get_dashboard_stats
from app.fusion.risk_fusion import risk_fusion

class TestFusionAndDB(unittest.TestCase):
    def setUp(self):
        init_db()

    def test_phishing_message_fusion(self):
        msg = "مبروك كسبت 50000 جنيه من فودافون كاش! دوس ع اللينك واستلم فلوسك: http://voda-cash-win.xyz/claim"
        result = risk_fusion.evaluate(msg)
        self.assertEqual(result["verdict"], "Phishing")
        self.assertGreaterEqual(result["final_risk_score"], 0.75)
        self.assertTrue(result["is_egyptian"])
        self.assertGreater(len(result["explanation_factors"]), 0)
        self.assertIn("ar", result["recommendations"])

    def test_safe_message_fusion(self):
        msg = "فودافون كاش: تم تحويل مبلغ 1500 جنيه إلى رقم 01012345678 بنجاح. رصيدك الحالي هو 3200 جنيه."
        result = risk_fusion.evaluate(msg)
        self.assertEqual(result["verdict"], "Safe")
        self.assertLess(result["final_risk_score"], 0.4)

    def test_pure_url_fusion(self):
        url = "http://192.168.1.104/vodafone-cash/login.php"
        result = risk_fusion.evaluate(url)
        self.assertEqual(result["input_type"], "url_only")
        self.assertEqual(result["verdict"], "Phishing")

    def test_database_insert_and_feedback(self):
        record = {
            "input_type": "combined",
            "raw_text": "رسالة اختبارية",
            "extracted_urls": ["http://test.com"],
            "detected_language": "ar",
            "text_risk_score": 0.8,
            "url_risk_score": 0.7,
            "final_risk_score": 0.75,
            "risk_level": "HIGH",
            "verdict": "Phishing",
            "confidence": 0.9,
            "explanation_factors": [{"severity": "HIGH", "description_ar": "عامل تجريبي"}],
            "processing_time_ms": 15.2,
            "user_feedback": None
        }
        new_id = insert_analysis(record)
        self.assertIsNotNone(new_id)

        # Submit feedback
        fb_id = save_feedback(new_id, "correct", "تحليل دقيق جدا")
        self.assertIsNotNone(fb_id)

        stats = get_dashboard_stats()
        self.assertGreaterEqual(stats["total_scans"], 1)

if __name__ == "__main__":
    unittest.main()
