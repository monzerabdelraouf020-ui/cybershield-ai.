import unittest
from app.nlp.arabic_preprocessor import normalize_arabic, detect_language, analyze_linguistic_heuristics
from app.nlp.text_classifier import text_classifier

class TestNLPModule(unittest.TestCase):
    def test_arabic_normalization(self):
        raw = "إِيقَافُ حِسَابِكَـ الـبنكيّ مَـعَـاً"
        norm = normalize_arabic(raw)
        self.assertNotIn("إ", norm)
        self.assertNotIn("ـ", norm)
        self.assertNotIn("ّ", norm)
        self.assertIn("ايقاف", norm)

    def test_egyptian_dialect_detection(self):
        egyptian_msg = "مبروك كسبت معانا 50 الف جنيه من فودافون كاش دوس ع اللينك واستلم فلوسك"
        det = detect_language(egyptian_msg)
        self.assertEqual(det["language"], "arz")
        self.assertTrue(det["is_egyptian"])
        self.assertIn("كسبت", det["egyptian_keywords_found"])

    def test_msa_arabic_detection(self):
        msa_msg = "عزيزي العميل، تم تسجيل دخول غير مصرح به إلى حسابك المصرفي."
        det = detect_language(msa_msg)
        self.assertEqual(det["language"], "ar")

    def test_english_detection(self):
        en_msg = "Urgent: Your PayPal account has been suspended due to suspicious activity."
        det = detect_language(en_msg)
        self.assertEqual(det["language"], "en")

    def test_linguistic_heuristics(self):
        scam_text = "تم إيقاف حسابك فورا! اضغط ع الرابط لتحديث البيانات وأرسل كود OTP!!"
        res = analyze_linguistic_heuristics(scam_text)
        self.assertGreater(res["linguistic_risk_score"], 0.4)
        self.assertGreater(len(res["factors"]), 1)

    def test_text_classifier_prediction(self):
        phish_text = "مبروك كسبت 50000 جنيه من فودافون كاش دوس ع اللينك واستلم فلوسك"
        res = text_classifier.predict(phish_text)
        self.assertGreater(res["text_risk_score"], 0.6)

        legit_text = "فودافون كاش: تم تحويل مبلغ 200 جنيه بنجاح. رصيدك الحالي 1500 جنيه."
        res_legit = text_classifier.predict(legit_text)
        self.assertLess(res_legit["text_risk_score"], 0.5)

if __name__ == "__main__":
    unittest.main()
