import unittest
from app.url.url_extractor import extract_urls
from app.url.feature_extractor import extract_url_features
from app.url.url_classifier import url_classifier

class TestURLModule(unittest.TestCase):
    def test_url_extraction(self):
        sample_text = "ادخل على الرابط التالي http://phishing-bank.xyz/login وسجل الآن أو زر https://google.com"
        urls = extract_urls(sample_text)
        self.assertEqual(len(urls), 2)
        self.assertIn("http://phishing-bank.xyz/login", urls)
        self.assertIn("https://google.com", urls)

    def test_ip_based_url_features(self):
        ip_url = "http://192.168.1.100/login"
        feat = extract_url_features(ip_url)
        self.assertEqual(feat["features"]["is_ip"], 1)
        self.assertGreater(feat["heuristic_score"], 0.4)

    def test_punycode_url_features(self):
        puny_url = "http://xn--pypal-4ve.com/account"
        feat = extract_url_features(puny_url)
        self.assertEqual(feat["features"]["is_punycode"], 1)

    def test_suspicious_tld_and_brand_impersonation(self):
        fake_url = "http://instapay-security.xyz/verify"
        feat = extract_url_features(fake_url)
        self.assertEqual(feat["features"]["is_suspicious_tld"], 1)
        self.assertEqual(feat["features"]["has_brand_lure"], 1)

    def test_url_classifier(self):
        malicious = url_classifier.analyze_single_url("http://192.168.1.50/vodafone-cash-claim.xyz")
        self.assertGreater(malicious["url_risk_score"], 0.7)

        benign = url_classifier.analyze_single_url("https://www.google.com")
        self.assertLess(benign["url_risk_score"], 0.35)

if __name__ == "__main__":
    unittest.main()
