chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "cybershield-inspect-link",
    title: "🛡️ فحص الرابط عبر CyberShield AI",
    contexts: ["link"]
  });

  chrome.contextMenus.create({
    id: "cybershield-inspect-text",
    title: "🛡️ فحص النص المحدد عبر CyberShield AI",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const target = info.linkUrl || info.selectionText;
  if (!target) return;

  try {
    const res = await fetch("http://127.0.0.1:8000/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: target })
    });

    if (res.ok) {
      const data = await res.json();
      const title = data.verdict === "Phishing" ? "🚨 خطر تصيد احتيالي!" : (data.verdict === "Suspicious" ? "⚠️ محتوى مشبوه" : "✅ محتوى آمن");
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon.png",
        title: title,
        message: `نسبة الخطورة: ${data.risk_percentage}% | ${data.verdict}`
      });
    }
  } catch (e) {
    console.error("Context menu scan error:", e);
  }
});
