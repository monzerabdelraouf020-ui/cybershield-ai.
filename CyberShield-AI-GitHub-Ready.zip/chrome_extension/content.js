// In-page link inspector for Google Chrome
console.log("🛡️ CyberShield AI link guard active on page.");
