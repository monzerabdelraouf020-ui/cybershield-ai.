const API_URL = "http://127.0.0.1:8000/api/analyze";

const scanCurrentTabBtn = document.getElementById("scanCurrentTabBtn");
const inputText = document.getElementById("inputText");
const analyzeBtn = document.getElementById("analyzeBtn");
const resultBox = document.getElementById("resultBox");
const verdictTitle = document.getElementById("verdictTitle");
const verdictBadge = document.getElementById("verdictBadge");
const riskScore = document.getElementById("riskScore");
const factorsList = document.getElementById("factorsList");

scanCurrentTabBtn.addEventListener("click", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0] && tabs[0].url) {
      inputText.value = tabs[0].url;
      runAnalysis(tabs[0].url);
    }
  });
});

analyzeBtn.addEventListener("click", () => {
  const val = inputText.value.trim();
  if (!val) {
    alert("الرجاء إدخال نص أو رابط أولاً");
    return;
  }
  runAnalysis(val);
});

async function runAnalysis(text) {
  analyzeBtn.disabled = true;
  analyzeBtn.textContent = "جاري الفحص بالذكاء الاصطناعي...";

  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text })
    });

    if (!res.ok) throw new Error("تعذر الاتصال بخادم CyberShield");
    const data = await res.json();
    renderResult(data);
  } catch (err) {
    alert("تنبيه: تأكد من تشغيل خادم CyberShield المحلي أو السحابي.\n" + err.message);
  } finally {
    analyzeBtn.disabled = false;
    analyzeBtn.textContent = "تحليل التهديد فوراً";
  }
}

function renderResult(data) {
  resultBox.style.display = "block";
  riskScore.textContent = `${data.risk_percentage}%`;

  verdictBadge.className = "badge";
  if (data.verdict === "Phishing") {
    verdictTitle.textContent = "🚨 رصد تصيد احتيالي!";
    verdictBadge.textContent = "PHISHING";
    verdictBadge.classList.add("badge-phish");
  } else if (data.verdict === "Suspicious") {
    verdictTitle.textContent = "⚠️ محتوى مشبوه";
    verdictBadge.textContent = "SUSPICIOUS";
    verdictBadge.classList.add("badge-susp");
  } else {
    verdictTitle.textContent = "✅ آمن وموثوق";
    verdictBadge.textContent = "SAFE";
    verdictBadge.classList.add("badge-safe");
  }

  factorsList.innerHTML = "";
  const factors = data.explanation_factors || [];
  if (factors.length > 0) {
    factors.slice(0, 3).forEach(f => {
      const li = document.createElement("li");
      li.textContent = f.description_ar || f.description_en;
      factorsList.appendChild(li);
    });
  } else {
    const li = document.createElement("li");
    li.textContent = "لم يتم رصد أي علامات تصيد أو استدراج.";
    factorsList.appendChild(li);
  }
}
